package tests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import enemies.Enemy;
import enemies.Warrior;
import handlers.EnemyHandler;
import helpz.Constants;
import main.Game;
import objects.PathPoint;
import scenes.Playing;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

	public class EnemyHandlerTests {
	   
		private EnemyHandler enemyHandler;
	    private TestPlaying testPlaying; // Saját tesztkörnyezet
	    private Enemy testEnemy;
	    PathPoint start;
	    PathPoint end;
	    @BeforeEach
	    public void setup() {
	        // Egyedi Playing példány a teszthez
	        testPlaying = new TestPlaying();

	        // EnemyHandler inicializálása a tesztkörnyezetben
	        start = new PathPoint(0, 0);
	        end = new PathPoint(5, 5);
	        enemyHandler = new EnemyHandler(testPlaying, start, end);

	        // Teszt ellenség létrehozása
	        testEnemy = new Warrior(1*32, 1*32, 1, enemyHandler); // Kezdőpozíció (32, 32)
	        testPlaying.setTile(1, 1, Constants.Tiles.ROAD_TILE); // amin áll az egy roadTile
	     // Hozzáadjuk az ellenséget az EnemyHandler-hez
	        enemyHandler.getEnemies().add(testEnemy);
	    }
	    @Test
	    public void testUpdate_EnemyMoves() {
	        // Inicializáljuk az ellenséget egy útvonalon
	        testEnemy.setPos(0, 0); // Kezdő pozíció
	        testEnemy.setLastDir(Constants.Direction.RIGHT); // Mozgás iránya: jobbra
	        
	        /* 	enemy 32,32  re van állítva tehát 1,1 ben van most
		 	    *   lvl[y][x] y sor x oszlop
		 	          mindegyik tile* 32 = kord ❌ ✔ 😈

		 	    	0,0________0,1________0,2________0,3________0,4________0,5________0,6
		 	    	|           |          |          |          |          |          |
		 	    	|    😈     |   🏁  ✔ |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	1,0________1,1________1,2________1,3________1,4________1,5________1,6
		 	    	|           |          |          |          |          |          |
		 	    	|    ❌     |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	2,0________2,1________2,2________2,3________2,4________2,5________2,6
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	3,0________3,1________3,2________3,3________3,4________3,5________3,6
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	4,0________4,1________4,2________4,3________4,4________4,5________4,6
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |    ✞     |
		 	    	|           |          |          |          |          |          |
		 	    	5,0________5,1________5,2________5,3________5,4________5,5________5,6
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |	
		 	    	6,0________6,1________6,2________6,3________6,4________6,5________6,6
*/
	        testPlaying.setTile(0, 0, Constants.Tiles.ROAD_TILE); // Kezdő tile
	        testPlaying.setTile(1, 0, Constants.Tiles.ROAD_TILE); // Cél tile

	         

	        // Update hívása
	        enemyHandler.update();

	        // Ellenőrizzük, hogy az ellenség elmozdult jobbra
	        assertEquals(32, testEnemy.getX(), "Jobbra kellett 1 tile-t mozdulni");
	        assertEquals(0, testEnemy.getY(), "Nem mozdulhatott el le vagy fel");
	    }

	    @Test
	    public void testMove_EnemySlowedEffect() {
	        // Inicializáljuk az ellenséget
	        testEnemy.setPos(0, 0); // Kezdő pozíció
	        testEnemy.setLastDir(Constants.Direction.RIGHT); // Mozgás iránya: jobbra
	       
	        /* 	enemy 32,32  re van állítva tehát 1,1 ben van most
		 	    *   lvl[y][x] y sor x oszlop
		 	          mindegyik tile* 32 = kord ❌ ✔ 😈

		 	    	0,0________0,1________0,2________0,3________0,4________0,5________0,6
		 	    	|           |          |          |          |          |          |
		 	    	|     😈    |    ✔    |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	1,0________1,1________1,2________1,3________1,4________1,5________1,6
		 	    	|           |          |          |          |          |          |
		 	    	|    ❌     |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	2,0________2,1________2,2________2,3________2,4________2,5________2,6
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	3,0________3,1________3,2________3,3________3,4________3,5________3,6
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	4,0________4,1________4,2________4,3________4,4________4,5________4,6
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	5,0________5,1________5,2________5,3________5,4________5,5________5,6
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |	
		 	    	6,0________6,1________6,2________6,3________6,4________6,5________6,6

		  */
	        //Pálya inicializálása
	        testPlaying.setTile(0, 0, Constants.Tiles.ROAD_TILE); // Kezdő tile
	        testPlaying.setTile(1, 1, Constants.Tiles.ROAD_TILE); // Következő tile
	        
	        // Lassító hatás alkalmazása
	        testEnemy.slow();
	       	  
	        float originalSpeed = Constants.Enemies.GetSpeed(testEnemy.getEnemy_type());
	        float slowedSpeed = originalSpeed *0.5f; // Lassítás: sebesség felezése

	        //move meghívása
	        testEnemy.move(Constants.Enemies.GetSpeed(testEnemy.getEnemy_type()),Constants.Direction.RIGHT);
	       
	        // Ellenőrizzük, hogy az ellenség lassított sebességgel mozgott
	        System.out.println("slowmozgás x: "+slowedSpeed +" X pozíció: "+testEnemy.getX());
	        assertEquals(slowedSpeed, testEnemy.getX(), "A speed felével kellett elmozdulni");
	        assertEquals(0, testEnemy.getY(), "Függőlegesen nem lehetett elmozdulás");
	        // Update hívása x = 32 re kéne átvinni az enemy-t
	        enemyHandler.update();
	        
	        assertTrue(testEnemy.getX()==32);
	    }

	    @Test 
	    void testIsAlive_atTheEnd() {
	    	testEnemy.setPos(5*32, 4*32);
	    	testEnemy.setLastDir(Constants.Direction.DOWN);
	    	testPlaying.setTile(5, 5, Constants.Tiles.ROAD_TILE);
	    	/* 	enemy 32,32  re van állítva tehát 1,1 ben van most
		 	    *   lvl[y][x] y sor x oszlop
		 	          mindegyik tile* 32 = kord ❌ ✔ 😈

		 	    	0,0________0,1________0,2________0,3________0,4________0,5________0,6
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	1,0________1,1________1,2________1,3________1,4________1,5________1,6
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	2,0________2,1________2,2________2,3________2,4________2,5________2,6
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	3,0________3,1________3,2________3,3________3,4________3,5________3,6
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |   😈     |
		 	    	|           |          |          |          |          |          |
		 	    	4,0________4,1________4,2________4,3________4,4________4,5________4,6
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |    ✞ 🏁  |
		 	    	|           |          |          |          |          |          |
		 	    	5,0________5,1________5,2________5,3________5,4________5,5________5,6
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |	
		 	    	6,0________6,1________6,2________6,3________6,4________6,5________6,6
*/
	    	// Ellenség mozgatása a pálya végére
	        testEnemy.setPos(end.getxCord() * 32, end.getyCord() * 32);

	        // Ellenőrizzük, hogy az ellenség elérte-e a célállomást
	        assertTrue(enemyHandler.isAtEnd(testEnemy), "Az ellenség a pálya végén van");

	        // IsAlive() ellenőrzése
	        enemyHandler.update(); // Frissítsük az állapotokat
	        assertFalse(testEnemy.isAlive(), "Itt már nem kéne élni az ellenségnek");
	    }
	    @Test
	    public void testSetNewDirectionAndMove_NoReturnToPreviousTile() {
	        // Az előző irány balra volt
	        testEnemy.setLastDir(Constants.Direction.LEFT);
	        /* 	enemy 32,32  re van állítva tehát 1,1 ben van most
		 	    *   lvl[y][x] y sor x oszlop
		 	          mindegyik tile* 32 = kord ❌ ✔ 😈

		 	    	0,0________0,1________0,2________0,3________0,4________0,5________0,6
		 	    	|           |          |          |          |          |          |
		 	    	|           |    ✔    |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	1,0________1,1________1,2________1,3________1,4________1,5________1,6
		 	    	|           |          |          |          |          |          |
		 	    	|    ❌     |   😈     |    ✔    |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	2,0________2,1________2,2________2,3________2,4________2,5________2,6
		 	    	|           |          |          |          |          |          |
		 	    	|           |     ✔   |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	3,0________3,1________3,2________3,3________3,4________3,5________3,6
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	4,0________4,1________4,2________4,3________4,4________4,5________4,6
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	5,0________5,1________5,2________5,3________5,4________5,5________5,6
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |
		 	    	|           |          |          |          |          |          |	
		 	    	6,0________6,1________6,2________6,3________6,4________6,5________6,6

		  */
	        // Körülöttünk "ROAD_TILE" van
	        testPlaying.setTile(0, 1, Constants.Tiles.ROAD_TILE); // Felfelé
	        testPlaying.setTile(1, 3, Constants.Tiles.ROAD_TILE); // Le
	        testPlaying.setTile(2, 2, Constants.Tiles.GRASS_TILE); // Jobbra

	        // Függvény meghívása
	        enemyHandler.setNewDirectionAndMove(testEnemy);

	        // Ellenőrizzük, hogy nem tér vissza balra
	        assertNotEquals(Constants.Direction.LEFT, testEnemy.getLastDir());
	    }

	    @Test
	    public void testSetNewDirectionAndMove_CorrectDirection() {
	        // Előző irány felfelé
	        testEnemy.setLastDir(Constants.Direction.DOWN);
	    	testPlaying.getEnemyHandler().UpdateEnemyMove(testEnemy);
	        testPlaying.setTile(1, 1, Constants.Tiles.ROAD_TILE);
	        /* 	enemy 32,32  re van állítva tehát 1,1 ben van most
	 	    *   lvl[y][x] y sor x oszlop
	 	          mindegyik tile* 32 = kord ❌ ✔ 😈

	 	    	0,0________0,1________0,2________0,3________0,4________0,5________0,6
	 	    	|           |          |          |          |          |          |
	 	    	|           |    ✔    |          |          |          |          |
	 	    	|           |          |          |          |          |          |
	 	    	1,0________1,1________1,2________1,3________1,4________1,5________1,6
	 	    	|           |          |          |          |          |          |
	 	    	|    ❌     |   😈     |    ❌    |          |          |          |
	 	    	|           |          |          |          |          |          |
	 	    	2,0________2,1________2,2________2,3________2,4________2,5________2,6
	 	    	|           |          |          |          |          |          |
	 	    	|           |     ❌   |          |          |          |          |
	 	    	|           |          |          |          |          |          |
	 	    	3,0________3,1________3,2________3,3________3,4________3,5________3,6
	 	    	|           |          |          |          |          |          |
	 	    	|           |          |          |          |          |          |
	 	    	|           |          |          |          |          |          |
	 	    	4,0________4,1________4,2________4,3________4,4________4,5________4,6
	 	    	|           |          |          |          |          |          |
	 	    	|           |          |          |          |          |          |
	 	    	|           |          |          |          |          |          |
	 	    	5,0________5,1________5,2________5,3________5,4________5,5________5,6
	 	    	|           |          |          |          |          |          |
	 	    	|           |          |          |          |          |          |
	 	    	|           |          |          |          |          |          |	
	 	    	6,0________6,1________6,2________6,3________6,4________6,5________6,6

	  */
	        // Körülöttünk tile-ok: csak felfelé érvényes
	        testPlaying.setTile(0, 1, Constants.Tiles.ROAD_TILE); // Felfelé
	        testPlaying.setTile(1, 0, Constants.Tiles.GRASS_TILE); // Balra
	        testPlaying.setTile(2, 1, Constants.Tiles.GRASS_TILE); // Jobbra
	        testPlaying.setTile(1, 2, Constants.Tiles.GRASS_TILE); // Le

	        // Függvény meghívása
	        enemyHandler.setNewDirectionAndMove(testEnemy); // -1 et ad vissza hiszen teljesen új irányt kér

	        // Ellenőrizzük, hogy felfelé mozgot
	       // System.out.println(""+testEnemy.getLastDir());
	     
	        assertEquals(testEnemy.getLastDir(),-1);  
	        //hívtunk neki egy setNewDirectionAndMove ot erre ő hívni fog egy resetDir-t
	    }

	    @Test
	    public void testSetNewDirectionAndMove_ChooseNewValidDirection() {
	        // Előző irány felfelé
	        testEnemy.setLastDir(Constants.Direction.UP);
	   /* 	enemy 32,32  re van állítva tehát 1,1 ben van most
	    *   lvl[y][x] y sor x oszlop
	          mindegyik tile* 32 = kord ❌ ✔ 😈

	    	0,0________0,1________0,2________0,3________0,4________0,5________0,6
	    	|           |          |          |          |          |          |
	    	|           |     ❌   |          |          |          |          |
	    	|           |          |          |          |          |          |
	    	1,0________1,1________1,2________1,3________1,4________1,5________1,6
	    	|           |          |          |          |          |          |
	    	|    ✔     |   😈     |    ✔    |          |          |          |
	    	|           |          |          |          |          |          |
	    	2,0________2,1________2,2________2,3________2,4________2,5________2,6
	    	|           |          |          |          |          |          |
	    	|           |    ❌    |          |          |          |          |
	    	|           |          |          |          |          |          |
	    	3,0________3,1________3,2________3,3________3,4________3,5________3,6
	    	|           |          |          |          |          |          |
	    	|           |          |          |          |          |          |
	    	|           |          |          |          |          |          |
	    	4,0________4,1________4,2________4,3________4,4________4,5________4,6
	    	|           |          |          |          |          |          |
	    	|           |          |          |          |          |          |
	    	|           |          |          |          |          |          |
	    	5,0________5,1________5,2________5,3________5,4________5,5________5,6
	    	|           |          |          |          |          |          |
	    	|           |          |          |          |          |          |
	    	|           |          |          |          |          |          |	
	    	6,0________6,1________6,2________6,3________6,4________6,5________6,6

 */
	        // Több irány is érvényes
	       // testPlaying.setTile(1, 1, Constants.Tiles.ROAD_TILE);
	        
	        testPlaying.setTile(0, 1, Constants.Tiles.GRASS_TILE); // Fel
	        testPlaying.setTile(1, 0, Constants.Tiles.ROAD_TILE); // Bal
	        testPlaying.setTile(1, 2, Constants.Tiles.GRASS_TILE); // Jobbra
	        testPlaying.setTile(3, 1, Constants.Tiles.ROAD_TILE); // LE
	        
	        // Függvény meghívása
	        enemyHandler.setNewDirectionAndMove(testEnemy);

	        // Ellenőrizzük, hogy új irányt választott (pl. le - 3 vagy balra - 0)
	        int lastDir = testEnemy.getLastDir();
	        assertTrue( lastDir != Constants.Direction.UP);
	        // 3 lehetőség vagy jobbra vagy balra vagy -1 és újra kezdi
	    }
	    @Test
	    public void testMoveInTheRightDirection_DOWN() {
	    	testEnemy.setLastDir(Constants.Direction.DOWN);
	    	/* 	enemy 32,32  re van állítva tehát 1,1 ben van most
	 	    *   lvl[y][x] y sor x oszlop
	 	          mindegyik tile* 32 = kord ❌ ✔ 😈 

	 	    	0,0________0,1________0,2________0,3________0,4________0,5________0,6
	 	    	|           |          |          |          |          |          |
	 	    	|           |     ❌   |          |          |          |          |
	 	    	|           |          |          |          |          |          |
	 	    	1,0________1,1________1,2________1,3________1,4________1,5________1,6
	 	    	|           |          |          |          |          |          |
	 	    	|    ❌     |   😈     |    ❌    |          |          |          |
	 	    	|           |          |          |          |          |          |
	 	    	2,0________2,1________2,2________2,3________2,4________2,5________2,6
	 	    	|           |          |          |          |          |          |
	 	    	|    ❌     |    ✔    |    ❌    |          |          |          |
	 	    	|           |    🏁    |          |          |          |          |
	 	    	3,0________3,1________3,2________3,3________3,4________3,5________3,6
	 	    	|           |          |          |          |          |          |
	 	    	|    ❌     |     ✔   |   ❌     |          |          |          |
	 	    	|           |          |          |          |          |          |
	 	    	4,0________4,1________4,2________4,3________4,4________4,5________4,6
	 	    	|           |          |          |          |          |          |
	 	    	|    ❌     |          |   ❌     |          |          |          |
	 	    	|           |     ✔   |          |          |          |          |
	 	    	5,0________5,1________5,2________5,3________5,4________5,5________5,6
	 	    	|           |          |          |          |          |          |
	 	    	|    ❌     |          |    ❌    |          |          |          |
	 	    	|           |    ✔    |          |          |          |          |	
	 	    	6,0________6,1________6,2________6,3________6,4________6,5________6,6

	  */	
	    	 	testPlaying.setTile(2, 1, Constants.Tiles.ROAD_TILE); 
		        testPlaying.setTile(3, 1, Constants.Tiles.ROAD_TILE); 
		        testPlaying.setTile(4, 1, Constants.Tiles.GRASS_TILE); 
		        testPlaying.setTile(5, 1, Constants.Tiles.ROAD_TILE); 
		        testEnemy.move(32, testEnemy.getLastDir());
		       // System.out.print("Move irány "+ testEnemy.getLastDir());
		        
		        assertTrue( testEnemy.getX()== 32 && testEnemy.getY() == 2*32 && testEnemy.getLastDir()== Constants.Direction.DOWN ); // Cél hogy x = 32 és y = 64 legyen
	    	
	    }
	    @Test
	    public void testMoveInTheRightDirection_RIGHT() {
	    	testEnemy.setLastDir(Constants.Direction.RIGHT);
	    	/* 	enemy 32,32  re van állítva tehát 1,1 ben van most
	 	    *   lvl[y][x] y sor x oszlop
	 	          mindegyik tile* 32 = kord ❌ ✔ 😈 

	 	    	0,0________0,1________0,2________0,3________0,4________0,5________0,6
	 	    	|           |          |          |          |          |          |
	 	    	|           |     ❌   |          |          |          |          |
	 	    	|           |          |          |          |          |          |
	 	    	1,0________1,1________1,2________1,3________1,4________1,5________1,6
	 	    	|           |          |          |          |          |          |
	 	    	|    ❌     |   😈     |    ✔    |   ✔     |  ✔      |  ✔      |
	 	    	|           |          |    🏁    |          |          |          |
	 	    	2,0________2,1________2,2________2,3________2,4________2,5________2,6
	 	    	|           |          |          |          |          |          |
	 	    	|    ❌     |    ❌    |    ❌    |          |          |          |
	 	    	|           |          |          |          |          |          |
	 	    	3,0________3,1________3,2________3,3________3,4________3,5________3,6
	 	    	|           |          |          |          |          |          |
	 	    	|    ❌     |     ❌   |   ❌     |          |          |          |
	 	    	|           |          |          |          |          |          |
	 	    	4,0________4,1________4,2________4,3________4,4________4,5________4,6
	 	    	|           |          |          |          |          |          |
	 	    	|    ❌     |          |   ❌     |          |          |          |
	 	    	|           |     ❌   |          |          |          |          |
	 	    	5,0________5,1________5,2________5,3________5,4________5,5________5,6
	 	    	|           |          |          |          |          |          |
	 	    	|    ❌     |          |    ❌    |          |          |          |
	 	    	|           |    ❌    |          |          |          |          |	
	 	    	6,0________6,1________6,2________6,3________6,4________6,5________6,6

	  */	
	    	 	testPlaying.setTile(1, 2, Constants.Tiles.ROAD_TILE); 
		        testPlaying.setTile(1, 3, Constants.Tiles.ROAD_TILE);
		        testPlaying.setTile(1, 4, Constants.Tiles.GRASS_TILE); 
		        testPlaying.setTile(1, 5, Constants.Tiles.ROAD_TILE); 
		        testEnemy.move(32, testEnemy.getLastDir());
		     //   System.out.print("Move irány"+ testEnemy.getLastDir());
		        
		        assertTrue( testEnemy.getX()== 2*32 && testEnemy.getY() == 1*32 && testEnemy.getLastDir()== Constants.Direction.RIGHT ); // Cél hogy x = 32 és y = 64 legyen
	    	
	    }
	    // Teszteléshez használt Playing osztály
	    // Ez csak azért kell hogy legyen egy 6x6os kis pályánk
	    private static class TestPlaying extends Playing {
	        private final int[][] level;

	        public TestPlaying() {
	            super(null); // Mivel Playing konstruktorában Game van, null-t adunk
	            level = new int[6][6]; // 6x6-es tesztpálya
	        }

	        public void setTile(int x, int y, int tileType) {
	            level[y][x] = tileType;
	        }

	        @Override
	        public int getTileType(int x, int y) {
	            // Ha kívül esik a pályán, GRASS_TILE-t ad vissza
	            if (x < 0 || x >= level[0].length || y < 0 || y >= level.length) {
	                return Constants.Tiles.GRASS_TILE;
	            }
	            return level[y][x];
	        }
	    }
	    }


