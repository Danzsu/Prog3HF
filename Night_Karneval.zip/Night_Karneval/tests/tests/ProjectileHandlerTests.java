package tests;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.awt.Point;
import java.awt.geom.Point2D;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;

import enemies.Enemy;
import enemies.Warrior;
import handlers.EnemyHandler;
import handlers.ProjectileHandler;
import helpz.Constants;
import objects.PathPoint;
import objects.Projectile;
import objects.Tower;
import scenes.Playing;

public class ProjectileHandlerTests {
	private EnemyHandler enemyHandler;
	private ProjectileHandler projectileHandler;
	private Tower testTower;
	private Enemy testEnemy;
    private Playing testPlaying; // Saját tesztkörnyezet
    Projectile projectile;
    PathPoint start;
    PathPoint end;
   
	@Before
	@BeforeEach
	public void setup() {
		// Egyedi Playing példány a teszthez
		start = new PathPoint(0, 0);
        end = new PathPoint(5, 5);
        testPlaying = new Playing(null);
        projectileHandler = new ProjectileHandler(testPlaying);
        // EnemyHandler inicializálása a tesztkörnyezetben
        enemyHandler = testPlaying.getEnemyHandler();
        
        testTower = new Tower(100, 100, 0,Constants.Towers.ARCHER);
	    testEnemy = new Warrior(200, 100,0, enemyHandler);
	    enemyHandler.getEnemies().add(testEnemy);
	}
	@Test
	public void testNewProjectile_Creation() {
		//Megnézzük hogy tényleg csak 1 projectile jött e létre és hogy megfelelő típusú e
	    projectileHandler.newProjectile(testTower, testEnemy);
	    projectile = projectileHandler.getProjectileList().get(0);
	    
	    assertEquals(1, projectileHandler.getProjectileList().size(),"A listában még csak 1 projectilenak kell lenni");
	    assertEquals(Constants.Projectiles.ARROW, projectile.getProjectileType(), "Megkell egyezni a torony által kilőtt projectilnak a létrejött");
	}

	@Test
	public void testNewProjectile_Reuse() {
		// Megnézzük hogy nem bővül a projectileok listája hanem a deaktivált helyére kerül be az új tehát felülírjuk
	    projectileHandler.newProjectile(testTower, testEnemy);
	    projectile = projectileHandler.getProjectileList().get(0);
	    projectile.setActive(false); // Inaktiváljuk a lövedéket

	    projectileHandler.newProjectile(testTower, testEnemy);

	    assertEquals(1, projectileHandler.getProjectileList().size(), "Nem nőtt a projectileok száma hiszen újrahasználtuk az elhalt projektile-t");
	    assertTrue(projectileHandler.getProjectileList().get(0).isActive(), "Aktívnak kell lenni a jelenlegi projectilenak");
	}
	@Test
	public void testUpdate_ProjectileMovement() {
		//Megnézzük hogy elmozdul e a projektile
	    projectileHandler.newProjectile(testTower, testEnemy);
	    projectile = projectileHandler.getProjectileList().get(0);

	    float initialX = projectile.getPos().x;

	    // mozgatja az élő projectileokat a p.move() al a move pedig a sebességük szerint elmozdítja őket x és y tengelyen
	    projectileHandler.update();
	    assertNotEquals(initialX, projectile.getPos().x, "Elmozdult a projektile");
	}
	
	@Test
	public void testUpdate_ProjectileHitsTarget() {
		//Találat érzékelése a projektile és enemy között
	    projectileHandler.newProjectile(testTower, testEnemy);
	    projectile = projectileHandler.getProjectileList().get(0);

	    projectile.setPos(new Point2D.Float(testEnemy.getX(), testEnemy.getY())); // Lövedék az ellenség pozícióján

	    int enemyHp = testEnemy.getHealth();
	    int projDmg = projectileHandler.getProjectileList().get(0).getDmg();
	    int enemyHpAfterHit= enemyHp-projDmg;
	    projectileHandler.update();

	    assertTrue(testEnemy.getHealth() == enemyHpAfterHit, "Eltalálta a targetet így életerőt vonunk le");
	    assertFalse(projectile.isActive(), "Eltalálta a targetet így deaktiválni kell a projektile-t");
	}
	@Test
	public void testProjectileType_ProjectileDamageByTowerType() {
		//Különböző tornyok különböző projectileokat hoznak létre amik nem ugyanolyanok ha más a torony
	    Tower archerTower = new Tower(100, 100, 0, Constants.Towers.ARCHER);
	    Tower cannonTower = new Tower(100, 100, 0, Constants.Towers.CANNON);

	    projectileHandler.newProjectile(archerTower, testEnemy);
	    Projectile arrow = projectileHandler.getProjectileList().get(0);

	    projectileHandler.newProjectile(cannonTower, testEnemy);
	    Projectile bomb = projectileHandler.getProjectileList().get(1);

	    assertNotEquals(arrow.getDmg(), bomb.getDmg(), "Különböző tornyoknak más dmg-e  van");
	    assertNotEquals(projectileHandler.getProjectileList().get(0).getProjectileType(),projectileHandler.getProjectileList().get(1).getProjectileType(),"Különböző tornyoknak más projectile fajtája van");
	}
	
	@Test
	public void testExplosion_DmgMultipleTarget() {
	    // Létrehozunk két ellenséget, amelyek közel vannak egymáshoz 32 vel eltolva az előzőhöz
	    Enemy secondEnemy = new Warrior(137, 100, 0, enemyHandler);
	    enemyHandler.getEnemies().add(secondEnemy);

	    // Robbanótorony és lövedék hozzáadása
	    testTower = new Tower(100, 100, 0, Constants.Towers.CANNON);
	    projectileHandler.newProjectile(testTower, testEnemy);

	    // Lövedék célba érkezése
	    Projectile bomb = projectileHandler.getProjectileList().get(0);
	    bomb.setPos(new Point2D.Float(testEnemy.getX(), testEnemy.getY()));

	    // Ellenségek kezdeti életereje
	    int enemystartHp1 = testEnemy.getHealth();
	    int enemystartHp2 = secondEnemy.getHealth();

	    // Frissítjük a ProjectileHandler-t, amely a robbanást kezelni fogja
	    projectileHandler.update();

//	    System.out.println("Találat Előtt 1. hp: " + enemystartHp1 +  ", Találat Után 1. hp: " + testEnemy.getHealth());
	 //   System.out.println("Találat Előtt 2. hp: " + enemystartHp2 + ", Találat Után 2. hp:" + secondEnemy.getHealth());

	    assertTrue(testEnemy.getHealth() < enemystartHp1, "Sebződni kellett");
	    assertTrue(secondEnemy.getHealth() < enemystartHp2, "Sebződni kellett");
	}

	@Test
	public void testUpdate_ProjectileOutOfBounds() {
	  // ha kiment a pályáról akkor a projectile-t deaktiválni kell
	    projectileHandler.newProjectile(testTower, testEnemy);
	    float x = 1000f;
	    float y = 1000f;
	    Point2D.Float pos = new Point2D.Float(x,y);
	    projectileHandler.getProjectileList().get(0).setPos(pos);;
	    projectileHandler.update();
	    projectile = projectileHandler.getProjectileList().get(0);
	    assertFalse(projectile.isActive(), "Ha kiment a pályáról akkor deaktiválni kell");
	}
	@Test
	public void testReset() {
	    //Minden projectilenak törlődnie kellett mert újraindítottunk

	    projectileHandler.newProjectile(testTower, testEnemy);
	    projectileHandler.update();

	    projectileHandler.reset();// akkor jön meghívásra ha ujraindítjuk a játékot

	    assertEquals(0, projectileHandler.getProjectileList().size(), "Újraindítottunk így törölni kell az egész listát");
	}
	@Test
	public void testProjectilePosition_ProjectileCreateInTheRightPosition() {
		//megnézzük hogy jó helyen jön e létre a projectile a tower közepén kell létre jönnie ami tower.x + 16 és tower.y + 16 a
		projectileHandler.newProjectile(testTower, testEnemy);
	    projectile = projectileHandler.getProjectileList().get(0);
	    System.out.println(""+ projectile.getPos().x+ projectile.getPos().y);
	    assertEquals((int)projectile.getPos().x , testTower.getX()+16);
	    assertEquals((int)projectile.getPos().y , testTower.getY()+16);
	}
    }

