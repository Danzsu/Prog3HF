package tests;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;

import enemies.Enemy;
import enemies.Warrior;
import handlers.EnemyHandler;
import handlers.TowerHandler;
import helpz.Constants;
import objects.PathPoint;
import objects.Tower;
import scenes.Playing;


public class TowerHandlerTests {
	private EnemyHandler enemyHandler;
	private TowerHandler towerHandler;
    private Playing testPlaying; // Saját tesztkörnyezet
    private Enemy testEnemy;
    Tower testTower;
    PathPoint start;
    PathPoint end;
    
    @Before
    @BeforeEach
    public void setup() {
        // Egyedi Playing példány a teszthez
        testPlaying = new Playing(null);

        // EnemyHandler inicializálása a tesztkörnyezetben
        start = new PathPoint(0, 0);
        end = new PathPoint(5, 5);
        enemyHandler = new EnemyHandler(testPlaying, start, end);
        
        towerHandler = new TowerHandler(testPlaying);
        // Teszt ellenség és toronylétrehozása
        testEnemy = new Warrior(105, 100, 1, enemyHandler); // Kezdőpozíció (32, 32)
        testTower = new Tower(100, 100, 0, Constants.Towers.ARCHER);
        // Hozzáadjuk az ellenséget az EnemyHandler-hez
        enemyHandler.getEnemies().add(testEnemy);
       
        
    }
	@Test
	public void testTower_AddTower() {
		//megnézzük hogy tudunk-e tornyot hozzáadni
		towerHandler.addTower(testTower, 100, 100);
		Tower addedTower = towerHandler.getTowerList().get(0);
	
		//System.out.println(" Tornyok száma: " +towerHandler.getTowerList().size()); 
		assertEquals(1, towerHandler.getTowerList().size(), "Egy toronynak kéne a Tornyok között lenni.");
	    assertEquals(100, addedTower.getX(), "A torony pozíciójának x koordinátájának megkell felelni");
	    assertEquals(100, addedTower.getY(), "A torony pozíciójának y koordinátájának megkell felelni");
	    assertEquals(Constants.Towers.ARCHER, addedTower.getTowerType(), "A torony típusának megkell felelni");
	}
	@Test
	public void testTower_RemoveTower() {
	    // megnézzük hogy tudunk e törölni tornyot
	    towerHandler.addTower(testTower, 100, 100);
	    towerHandler.removeTower(testTower);
	    
	    assertEquals(0, towerHandler.getTowerList().size(), "Üresnek kell lenni a toronyListának hiszen kiszedtük belőle az egyetlen egy tornyot");
	}
	@Test
	public void testUpdateTower() {
		//Megnézzük hogy frissíthető e a torony
	    towerHandler.addTower(testTower, 100, 100);
	    int cooldown = (int)Constants.Towers.GetDefaultCooldown(Constants.Towers.ARCHER);
	   // int initialCooldownTick = testTower.getCooldownTick();
	    testTower.resetCooldown();
	    for(int i=0;i<=cooldown;i++)
	    	testTower.update();
	  //  System.out.println(" "+testTower.isCooldownOver());

	   assertTrue(testTower.isCooldownOver()== true, "Túlkellett nőnie a cooldownTicknek a cooldownt tehát igazat ad vissza");
	}
	@Test
	public void testUpgradeTower() {
		//mehnézzük hogy tudjuk e fejleszteni a tornyot
		testTower =  new Tower(100, 100, 1, Constants.Towers.ARCHER);
	    towerHandler.addTower(testTower, 100, 100);
	    int initialDamage = testTower.getDmg();
	    float initialRange = testTower.getRange();
	    
	  //  System.out.println(""+testTower.getTier());
	    testTower.upgradeTower();
	    
	    
	 //   System.out.println(""+testTower.getTier());
	    assertEquals(2, testTower.getTier(), "Megnövekedett a torny szintjének száma");
	    assertTrue(testTower.getDmg() > initialDamage, "Torony sebzés megnövekedett");
	    assertTrue(testTower.getRange() > initialRange, "Torony lőtávolsága megnövekedett");
	}
	/* Megpróbáltam de nem jöttem rá hogy miért nem jó 
	 * Addig jutottam hogy a TowerHandler attackEnemyWithinRange én belüli enemyList nek null-t kap valószínűleg
	@Test
	public void testAttackEnemy() {
	    testTower = new Tower(100, 100, 0, Constants.Towers.ARCHER);
	 
	    towerHandler.getTowerList().add(testTower);
	   
	    System.out.println("Enemy Lista : "+ enemyHandler.getEnemies().size());
	    
	    System.out.println(" Enemy él " + enemyHandler.getEnemies().get(0).isAlive());
	    
	    System.out.println(" Torony lista " + towerHandler.getTowerList().size());
	    System.out.println(" "+towerHandler.isEnemyInRange(testTower, enemyHandler.getEnemies().get(0)));
	    towerHandler.isEnemyInRange(testTower, testEnemy);
	    int initialHp = testEnemy.getHealth();
	    System.out.println(" " + testEnemy.getHealth() + " enemyHandler " +enemyHandler.getEnemies().get(0).getHealth());
	   
	    towerHandler.update();
	    
	    System.out.println(" " + testEnemy.getHealth() + " enemyHandler " +enemyHandler.getEnemies().get(0).getHealth());
	    assertTrue(testEnemy.getHealth() < initialHp, "Enemy health should decrease after being attacked by the tower.");
	}*/
	@Test
	public void testEnemyOutOfRange() {
		//Megnézzük hogy az enemy out of range e
	    testTower = new Tower(100, 100, 0, Constants.Towers.ARCHER);
	    towerHandler.addTower(testTower, 100, 100);

	    testEnemy = new Warrior(300, 300, 0, enemyHandler); // Kívül van a torony hatótávján
	    enemyHandler.getEnemies().add(testEnemy);

	    
	    towerHandler.update();

	    assertTrue(towerHandler.isEnemyInRange(testTower, testEnemy) == false, "Ha az enemy Out of range akkor nem kell hogy dmg-et kapjon ");
	}
	@Test
	public void testResetTowerHandler() {
		//Játék újdraindításakor kiürítjül a listát és lenullázzuk a tornyokat
		towerHandler.getTowerList().add(testTower);
	    Tower testTower2 = new Tower(100, 100, 0, Constants.Towers.ARCHER);
	    towerHandler.addTower(testTower2, 100, 100);
	     int numberofTowers = towerHandler.getTowerList().size();
	     //System.out.println(" " + numberofTowers);
	     assertEquals(2,numberofTowers,"Kettő Tornyunk van jelenleg");
	     towerHandler.reset();
	     assertEquals(0, towerHandler.getTowerList().size(), "Kiürítették a toronylistát hiszen újrakezdjük a játékot");
	}

	
}
