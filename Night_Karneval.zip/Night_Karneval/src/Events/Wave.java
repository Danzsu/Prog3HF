package Events;

import java.util.ArrayList;
//A Wave osztály felelős a hullámok létrehozásáért, amelyek az ellenségek megjelenését szabályozzák
public class Wave {
	private ArrayList<Integer> enemyList;
	public Wave(ArrayList<Integer> enemyList) {
		this.enemyList = enemyList;
	}
	public ArrayList<Integer> getEnemyList(){
		return enemyList;
	}
}