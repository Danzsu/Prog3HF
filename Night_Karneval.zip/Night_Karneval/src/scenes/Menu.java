package scenes;

import java.awt.Graphics;
import main.Game;
import ui.MyButton;
import static main.GameStates.*;

public class Menu extends GameScene implements SceneMethods {
	
	//TODO a gomboknál szimpla felirat helyett lehetne képeket adni későbbi fejlesztésben
	private MyButton b_Play,b_Edit,b_Settings,b_Quit;
	
	public Menu(Game game) {
		super(game);
	
		initButtons();
	}
	private void initButtons() {
		int w= 150;
		int h = w/3;
		int x = 640 /2 -w /2;
		int y = 150;
		int y_next_dist=100;
		b_Play = new  MyButton("Play",x,y,w,h);
		b_Edit = new MyButton("Edit",x,y+y_next_dist,w,h);
		b_Settings = new MyButton("Settings",x,y+2*y_next_dist,w,h);
		b_Quit = new MyButton("Quit",x,y+3*y_next_dist,w,h);
	
		
	}

	@Override
	public void render(Graphics G) {
		drawButtons(G);
			
		
	}
	private void drawButtons(Graphics g) {
		b_Play.draw(g);
		b_Edit.draw(g);
		b_Settings.draw(g);
		b_Quit.draw(g);
		
		
	}

	@Override
	public void mouseClicked(int x, int y) {
		if(b_Play.getBounds().contains(x,y)) {
			this.getGame().getPlaying().resetEverything();
			setGameState(PLAYING);
		
		}
		else if(b_Edit.getBounds().contains(x,y)) {
			setGameState(EDIT);
		
		}
		else if(b_Settings.getBounds().contains(x,y)) {
			setGameState(SETTINGS);
		
		}
		
		else if(b_Quit.getBounds().contains(x,y)) {
			System.exit(0);

		}
		
		
	}

	@Override
	public void mouseMoved(int x, int y) {
		b_Play.setMouseOver(false);
		b_Edit.setMouseOver(false);
		b_Quit.setMouseOver(false);
		b_Settings.setMouseOver(false);
		
		if(b_Play.getBounds().contains(x, y)) {
			b_Play.setMouseOver(true);
		}
		if(b_Edit.getBounds().contains(x, y)) {
			b_Edit.setMouseOver(true);
		}
		else if(b_Settings.getBounds().contains(x, y)) {
			b_Settings.setMouseOver(true);
		}
		else if(b_Quit.getBounds().contains(x, y)) {
			b_Quit.setMouseOver(true);
		}
		
	}

	@Override
	public void mousePressed(int x, int y) {
		// itt nem működik az ami fentebb a moved esetén hogy visszaállítjuk falsera ehelyett a mouseReleased be kell beállítani falsera
		
		if(b_Play.getBounds().contains(x, y)) {
			b_Play.setMousePressed(true);
		}
		if(b_Edit.getBounds().contains(x, y)) {
			b_Edit.setMousePressed(true);
		}
		else if(b_Settings.getBounds().contains(x, y)) {
			b_Settings.setMousePressed(true);
		}
		else if(b_Quit.getBounds().contains(x, y)) {
			b_Quit.setMousePressed(true);
		}
		
		
	}

	@Override
	public void mouseReleased(int x, int y) {
		resetButtons();
		
	}

	private void resetButtons() {
		b_Play.resetBool();
		b_Settings.resetBool();
		b_Quit.resetBool();
		b_Edit.resetBool();
		
	}

	@Override
	public void mouseDragged(int x, int y) {
		// TODO Auto-generated method stub
		
	}
}
