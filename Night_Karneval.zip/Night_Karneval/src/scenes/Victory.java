package scenes;

import static main.GameStates.MENU;
import static main.GameStates.EDIT;
import static main.GameStates.setGameState;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import main.Game;
import ui.MyButton;

public class Victory extends GameScene implements SceneMethods {
	private MyButton b_Editing,b_Menu;
	public Victory(Game game) {
		super(game);
		initButtons();
	}

	private void initButtons() {
		int w= 150;
		int h = w/3;
		int x = 640 /2 -w /2;
		int y = 300;
		int y_next_dist=100;
		
		b_Menu = new  MyButton("Menu",x,y,w,h);
		b_Editing = new MyButton("Editing",x,y+y_next_dist,w,h);
		
	}
	@Override
	public void render(Graphics g) {
		//game over text
		g.setColor(Color.green);
		g.setFont(new Font("Dialog",Font.BOLD,50));
		g.drawString("Victory !", 220, 180);
		//button
		g.setFont(new Font("LucidaSans",Font.BOLD,20));
		b_Menu.draw(g);
		b_Editing.draw(g);
		//editing
		//menu
		
	}
	private void resetAll() {
		this.getGame().getPlaying().resetEverything();
	}
	@Override
	public void mouseClicked(int x, int y) {
		if(b_Menu.getBounds().contains(x,y)) {
			resetAll();
			setGameState(MENU);
		}	
		else if(b_Editing.getBounds().contains(x,y)) {
			resetAll();
			setGameState(EDIT);
		}

		
	}

	

	@Override
	public void mouseMoved(int x, int y) {
		b_Menu.setMouseOver(false);
		b_Editing.setMouseOver(false);
		if(b_Menu.getBounds().contains(x,y))
			b_Menu.setMouseOver(true);
		else if(b_Editing.getBounds().contains(x,y))
			b_Editing.setMouseOver(true);
		
	}

	@Override
	public void mousePressed(int x, int y) {
		if(b_Menu.getBounds().contains(x,y))
			b_Menu.setMousePressed(true);
		else if(b_Editing.getBounds().contains(x,y))
			b_Editing.setMousePressed(true);
		
	}

	@Override
	public void mouseReleased(int x, int y) {
		b_Menu.resetBool();
		b_Editing.resetBool();
		
	}

	@Override
	public void mouseDragged(int x, int y) {
		// TODO Auto-generated method stub
		
	}
}