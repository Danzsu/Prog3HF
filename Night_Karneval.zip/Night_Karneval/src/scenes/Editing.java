package scenes;

import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import handlers.TileHandler;
import helpz.LoadSave;
import main.Game;
import objects.PathPoint;
import objects.Tile;
import ui.ActionBar;
import ui.ToolBar;

import static helpz.Constants.Tiles.*;

public class Editing extends GameScene implements SceneMethods{

	private int[][] lvl;	
	private Tile selectedTile;
	private int mouse_X,mouse_Y;
	private int lastTileY,lastTileX,lastTileId;
	private boolean drawSelect;
	private ToolBar toolbar;
	private PathPoint start,end;
	
	
	
	public Editing(Game game) {
		super(game);
		loadDeffLevel();
		toolbar = new ToolBar(0,640,640,160,this);
	}
	
	
	public void update() {
		updateTick();
	}
	@Override
	public void render(Graphics g) {
		update();
		drawLvL(g);
		toolbar.draw(g);
		drawSelectedTile(g);	
		drawPathPoints(g);
	}
	
	private void loadDeffLevel() {
		lvl = LoadSave.GetLevelData("new level");
		ArrayList<PathPoint> points = LoadSave.GetLevelPathPoints("new level");
		start = points.get(0);
		end = points.get(1);
	}
	
	/// Grafikus függvények kirajzoláshoz a render-hez
	
	private void drawPathPoints(Graphics g) {
		if(start !=null) {
			g.drawImage(toolbar.getStartPathImg(), start.getxCord()*32, start.getyCord()*32,32,32, null);
		}
		if(end !=null) {
			g.drawImage(toolbar.getEndPathImg(), end.getxCord()*32, end.getyCord()*32,32,32, null);
		}
		
	}


	public void drawLvL(Graphics g) {
		for (int y=0;y<lvl.length;y++) {
			for(int x = 0; x<lvl[y].length;x++) {
				int id = lvl[y][x];
				if(isAnimation(id)) {
					g.drawImage(getSprite(id,animationIndex), x*32, y*32, null);
				}else
					g.drawImage(getSprite(id), x*32, y*32, null);
			}
		
	}
}

	private void drawSelectedTile(Graphics g) {
		if(selectedTile != null && drawSelect) {
			g.drawImage(selectedTile.getSprite(),mouse_X,mouse_Y,32,32,null);
		}
		
	}
	
	/// működést befolyásoló függvények
	
	public void saveLevel() {
		LoadSave.SaveLevel("new Level",lvl,start,end);  // így újraindítás nélkül egyből az edit utána a játékban is érzékeljük a változást
		this.getGame().getPlaying().setLevel(lvl,start,end);
	}
	public void setSelectedTile(Tile tile) {
		this.selectedTile=tile;
		drawSelect = true;
	}
	
	private void changeTile(int x, int y) {
		//TODO ha a képernyőn kívülre viszem az egeret az nincs lekezelve
		if(selectedTile != null) {
			
			int tileX= x/32; //megkapjuk a koordinátáját a tile nak a level listában lévő helyét
			int tileY= y/32;
			
			if(selectedTile.getId()>=0) {
			
			//kis optimalizálás hogy ne kelljen mindig újra rajzolni csak akkor ha más a tile
			if(lastTileX == tileX && lastTileY == tileY && lastTileId == selectedTile.getId()) 
				return;
			
			lastTileX = tileX;
			lastTileY = tileY;
			lastTileId= selectedTile.getId();
			lvl[tileY][tileX] = selectedTile.getId();
				}
			else {
				int id = lvl[tileY][tileX];
				if(this.getGame().getTileHandler().getTile(id).getTileType() == ROAD_TILE) {
					if(selectedTile.getId()==-1) 
						start = new PathPoint(tileX,tileY);
					else
						end=new PathPoint(tileX,tileY);
				}
			}
		}
		
	}
	
	/// MOUSE AND KEY EVENTS HANDLE
	
	@Override
	public void mouseClicked(int x, int y) {
		if(y>=640) {
			toolbar.mouseClicked(x, y);
		}
		else {
			changeTile(mouse_X,mouse_Y);
		}
		
		
	}

	@Override
	public void mouseMoved(int x, int y) {
		if(y>=640) {
			toolbar.mouseMoved(x, y);
			drawSelect = false; // ez azt oldja meg hogy ne legyen az egerünkön az ikon amikor a gombokra visszük az egeret
		}else {
			drawSelect = true;
			mouse_X = (x/32) *32; // így mostmár folyomatosan egy mezőre wrappel rá az egér amikor elvisszük fölötte mert pontos koordinátákkal dolgozik amíg 32x32 es elemeket használunk
			mouse_Y = (y/32) *32;
		
		}
	
	}

	@Override
	public void mousePressed(int x, int y) {
		if(y>=640)
			toolbar.mousePressed(x, y);
	
	}

	@Override
	public void mouseReleased(int x, int y) {
		toolbar.mouseReleased(x, y);
		
	}
	@Override
	public void mouseDragged(int x, int y) {
		if(y>=640) {
			
		}else {
			changeTile(x,y);
		}
		
	}
	public void keyPressed(KeyEvent e) {
		// a KeyEvent-ben a VK-k a virtual keys és az _ utáni rész hogy melyik billentyű az amivel szeretnénk interaktálni
		if(e.getKeyCode() == KeyEvent.VK_R) {
			toolbar.nextSprite();
		}
	}
	public int[][] getLevelFromEdit(){
		return lvl;
	}
	public PathPoint getStartEdit(){
		return start;
	}
	public PathPoint getEndEdit(){
		return start;
	}

}
