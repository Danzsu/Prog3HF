package scenes;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import main.Game;
import ui.MyButton;
import static main.GameStates.*;
public class GameOver extends GameScene implements SceneMethods{
	private MyButton b_Replay,b_Menu;
	public GameOver(Game game) {
		super(game);
		initButtons();
	}

	private void initButtons() {
		int w= 150;
		int h = w/3;
		int x = 640 /2 -w /2;
		int y = 300;
		int y_next_dist=100;
		
		b_Menu = new  MyButton("Menu",x,y,w,h);
		b_Replay = new MyButton("Replay",x,y+y_next_dist,w,h);
		
	}
	@Override
	public void render(Graphics g) {
		//game over text
		g.setColor(Color.red);
		g.setFont(new Font("Dialog",Font.BOLD,50));
		g.drawString("GAME OVER !", 160, 100);
		//button
		g.setFont(new Font("LucidaSans",Font.BOLD,20));
		b_Menu.draw(g);
		b_Replay.draw(g);
		//replay
		//menu
		
	}
	private void resetAll() {
		this.getGame().getPlaying().resetEverything();
	}
	private void replayGame() {
		// reset everything
		resetAll();
		// change state to playing
		setGameState(PLAYING);
		
	}
	@Override
	public void mouseClicked(int x, int y) {
		if(b_Menu.getBounds().contains(x,y)) {
			resetAll();
			setGameState(MENU);
		}	
		else if(b_Replay.getBounds().contains(x,y)) {
			replayGame();
		}

		
	}

	

	@Override
	public void mouseMoved(int x, int y) {
		b_Menu.setMouseOver(false);
		b_Replay.setMouseOver(false);
		if(b_Menu.getBounds().contains(x,y))
			b_Menu.setMouseOver(true);
		else if(b_Replay.getBounds().contains(x,y))
			b_Replay.setMouseOver(true);
		
	}

	@Override
	public void mousePressed(int x, int y) {
		if(b_Menu.getBounds().contains(x,y))
			b_Menu.setMousePressed(true);
		else if(b_Replay.getBounds().contains(x,y))
			b_Replay.setMousePressed(true);
		
	}

	@Override
	public void mouseReleased(int x, int y) {
		b_Menu.resetBool();
		b_Replay.resetBool();
		
	}

	@Override
	public void mouseDragged(int x, int y) {
		// TODO Auto-generated method stub
		
	}

}
