package scenes;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import main.Game;
import static main.GameStates.*;
import ui.MyButton;
//Ezt az osztályt nem implementáltam teljesen, mert a játékban alapból nincs nehézségi szint, de ha lenne akkor a nehézségi szintet itt lehetne beállítani
//A nehézségi szinttől függően a játékban létrehozott wavek nehézsége is változna
public class Settings extends GameScene implements SceneMethods{
	private MyButton b_Menu;
	public Settings(Game game) {
		super(game);
		initButtons();
	}
	//settings ide mennének a nehézségek ami szerint a PLAYING ben létrehozza a waveket
	@Override
	public void render(Graphics g) {
		g.setColor(Color.white);
		g.fillRect(0, 0, 640, 640);
		g.setColor(Color.red);
		g.setFont(new Font("Monospaced",Font.BOLD,25));
		g.drawString("Későbbi fejlesztés nehézségi fokozat", 50, 200);
		g.setFont(new Font("Monospaced",Font.PLAIN,12));
		drawButtons(g);
	}
	private void initButtons() {
		b_Menu =new MyButton("Menu",2,2,100,30);
	}
	private void drawButtons(Graphics g) {
		b_Menu.draw(g);
		
	}
	@Override
	public void mouseClicked(int x, int y) {
		if(b_Menu.getBounds().contains(x, y)) {
			setGameState(MENU);
		}
		
	}

	@Override
	public void mouseMoved(int x, int y) {
		b_Menu.setMouseOver(false);
		if(b_Menu.getBounds().contains(x, y)) {
			b_Menu.setMouseOver(true);
		}
		
	}

	@Override
	public void mousePressed(int x, int y) {
		if(b_Menu.getBounds().contains(x, y)) {
			b_Menu.setMousePressed(true);
		}
		
	}

	@Override
	public void mouseReleased(int x, int y) {
		resetButtons();
		
	}
	
	private void resetButtons() {
		b_Menu.resetBool();
		
	}

	@Override
	public void mouseDragged(int x, int y) {
		// TODO Auto-generated method stub
		
	}

}
