package scenes;

import java.awt.image.BufferedImage;
import main.Game;

public abstract  class  GameScene {
	private Game game;
	protected int tick;
	protected int ANIMATION_SPEED = 30;
	protected int animationIndex;
	public GameScene(Game game) {
		this.game = game;
	}
	public Game getGame() {
		
		return game;
	}
	protected boolean isAnimation (int spriteID) {
		return this.getGame().getTileHandler().isSpriteAnimation(spriteID);
	}
	protected void updateTick() {
		tick++;
		if(tick>= ANIMATION_SPEED) {
			tick = 0;
			animationIndex++;
			if(animationIndex >= 4)
				animationIndex =0;
			}

	}
	protected BufferedImage getSprite(int spriteID) {
		return getGame().getTileHandler().getSprite(spriteID);
	}
	protected BufferedImage getSprite(int spriteID,int animationIndex) {
		return getGame().getTileHandler().getAniSprite(spriteID,animationIndex);
	}
	
}
