package scenes;


import enemies.Enemy;
import handlers.EnemyHandler;
import handlers.ProjectileHandler;
import handlers.TowerHandler;
import handlers.WaveHandler;
import static helpz.Constants.Tiles.GRASS_TILE;
import helpz.LoadSave;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import main.Game;
import objects.PathPoint;
import objects.Tower;
import ui.ActionBar;
import static main.GameStates.setGameState;
import static main.GameStates.VICTORY;

public class Playing extends GameScene implements SceneMethods {
	private int[][] lvl;
	private ActionBar actionbar;
	private int mouse_X,mouse_Y;
	private EnemyHandler enemyHandler;
	private TowerHandler towerHandler;
	private ProjectileHandler projectileHandler;
	
	private PathPoint start,end;
	private Tower selectedTower;
	
	private WaveHandler waveHandler;
	private boolean gamePaused = false;
	
	//Konstruktor 
	//A játékban a Playing osztály felelős a játékmenetért
	//A Playing osztályban találhatóak a játékmenethez szükséges objektumok és a játékmenetet irányító metódusok
	public Playing(Game game) {
		super(game);
		//the lvl
		loadDeffLevel();
	
		// tilehandler communication
		
		actionbar = new ActionBar(0,640,640,160,this);
		enemyHandler = new EnemyHandler(this,start,end);
		towerHandler = new TowerHandler(this);
		projectileHandler = new ProjectileHandler(this);
		waveHandler = new WaveHandler(this);
	}
	//A játékmenetet frissítő metódus 
	public void update() {
		if(!gamePaused) {
			updateTick();//
			waveHandler.update();//WaveHandler update 
			
			//Gold tick
			actionbar.passiveGoldUpdate();
			
			//Ha az összes ellenség meghalt és nincs több hullám akkor a játék véget ér
			if(isAllEnemiesDead()) {
				if(isThereMoreWaves()) {
					waveHandler.startWaveTimer();
					if(isWaveTimerOver()) {
						waveHandler.incrWaveIndex();
						enemyHandler.getEnemies().clear();
						waveHandler.resetEnemyIndex();
					}
					
					
				}
				else {
					setGameState(VICTORY);
				}
					
			}
			if(isTimeForNewEnemy()) {
				spawnEnemy();
			}
			enemyHandler.update();
			towerHandler.update();
			projectileHandler.update();
		}
		
		

	}
	private boolean isWaveTimerOver() {
		return waveHandler.isWaveTimeOver();
	}

	private boolean isThereMoreWaves() {
		return waveHandler.isThereMoreWaves();
	}

	private boolean isAllEnemiesDead() {
		if(waveHandler.isThereMoreEnemiesInCWave()) {
			return false;
		}
		//hamis pozitív lenne ha még nem jönne létre a következő enemy de már az előző halott lenne
		//ezért kell fölé a check
		for(Enemy e : enemyHandler.getEnemies()) {
			if(e.isAlive())
				return false;
		}
		return true;
	}

	private void spawnEnemy() {
		enemyHandler.spawnEnemy(getWaveHandler().getNextEnemy());
	}

//Az új ellenségek spawnolásának időzítését szabályozza
	private boolean isTimeForNewEnemy() {
		if(waveHandler.isTimeForNewEnemy()) {
			if(waveHandler.isThereMoreEnemiesInCWave())
				return true;
		}
		return false;
	}
	//Az alapértelmezett pálya betöltése
	private void loadDeffLevel() {
		lvl = LoadSave.GetLevelData("new level");
		ArrayList<PathPoint> points = LoadSave.GetLevelPathPoints("new level");
		start = points.get(0);
		end = points.get(1);
	}
	

	@Override
	// A játékmenetet megjelenítő metódus 
	public void render(Graphics g) {
		drawLvL(g);
		actionbar.draw(g);
		
		enemyHandler.draw(g);
		towerHandler.draw(g);
		projectileHandler.draw(g);
		
		drawSelectedTower(g);
		drawHighLight(g);
		
		drawWaveInfos(g);
		
	}
	
	private void drawWaveInfos(Graphics g) {
		if(waveHandler.isWaveTimerStarted()) {
			
		}
		
	}

	private void drawHighLight(Graphics g) {
		g.setColor(Color.white);
		g.drawRect(mouse_X, mouse_Y, 32, 32);
		
	}

	private void drawSelectedTower(Graphics g) {
		if(selectedTower != null)
			g.drawImage(towerHandler.getTowerImgs()[selectedTower.getTowerType()], mouse_X, mouse_Y, null);
	}

	public void drawLvL(Graphics g) {
		for (int y=0;y<lvl.length;y++) {
			for(int x = 0; x<lvl[y].length;x++) {
				int id = lvl[y][x];
				g.drawImage(getSprite(id), x*32, y*32, null);
				if(isAnimation(id)) {
					g.drawImage(getSprite(id,animationIndex), x*32, y*32, null);
				}else
					g.drawImage(getSprite(id), x*32, y*32, null);
			}
		
		}
	}
	// a tile típusa alapján visszaadja a hogy melyik tile van ott
	//A tornyok miatt fontos hiszen azokat csak a fűre lehet lerakni
	private boolean isTileGrass(int x, int y) {
		int id = lvl[y/32][x/32];
		int tileType = this.getGame().getTileHandler().getTile(id).getTileType();
		if(tileType==GRASS_TILE) {
			return true;
		}
		return false;
	}
	// új projectile létrehozása hiszen enemyre lőttünk
	public void shootEnemy(Tower t,Enemy e) {
		projectileHandler.newProjectile(t, e);
	}
	
	private void payTowerPrice(int towerType) {
		actionbar.payForTower(towerType);
		
	}
	public void removeTower(Tower displayedTower) {
		towerHandler.removeTower(displayedTower);
		
	}
	public void upgradeTower(Tower displayedTower) {
		towerHandler.upgradeTower(displayedTower);
		
	}
	// MOUSE EVENTS HANDLE
	
	@Override
	public void mouseClicked(int x, int y) {
		
		if(y>=640) {
			actionbar.mouseClicked(x, y);
		}
		else {
			if(selectedTower != null) {
				if(isTileGrass(mouse_X,mouse_Y)) {
					if(getTowerAt(mouse_X,mouse_Y)==null){// ha nincs rajta torony az adott pozíción
						towerHandler.addTower(selectedTower,mouse_X,mouse_Y);
						payTowerPrice(selectedTower.getTowerType());
						selectedTower = null;
						
						
					}
				}
			}else {
				// kapjuk meg a tornyot ha jó helyen van az egér
				Tower t = getTowerAt(mouse_X,mouse_Y);
				actionbar.displayTower(t);
			}
		}			
	}

	

	@Override
	public void mouseMoved(int x, int y) {
			
			if(y>=640) { //
				actionbar.mouseMoved(x, y);
			}else {				
				mouse_X = (x/32) *32; // így mostmár folyomatosan egy mezőre wrappel rá az egér amikor elvisszük fölötte mert pontos koordinátákkal dolgozik amíg 32x32 es elemeket használunk
				mouse_Y = (y/32) *32;
			
			}
	}

	@Override
	public void mousePressed(int x, int y) {
		
		if(y>=640) {
			actionbar.mousePressed(x, y);
		}
		
	}

	@Override
	public void mouseReleased(int x, int y) {
			actionbar.mouseReleased(x, y);
	}
	@Override
	public void mouseDragged(int x, int y) {

		
	}
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_C)
			selectedTower = null;
		
	}
	public void rewardPlayer(int enemyType) {
		actionbar.addGold(helpz.Constants.Enemies.GetReward(enemyType));
	}
	
	public void setGamePaused(boolean gamePaused) {
		this.gamePaused = gamePaused;
	}
	//Getter & Setter code
	
	//azért kell hogy az enemynél a mozgatásnál letudjuk kérni azt hogy milyen típusú tile-on áll
	public int getTileType(int x, int y) {
			
			//Bounds out of index error ellenőrzése
			//20x20 as a pálya tehát ha 0 kisebb vagy nagyobb mint 19 akkor azt kezeljük le
			int xCord = x/32;
			int yCord = y/32;
			if(xCord <0 || xCord >19)
				return 0;
			if(yCord <0 || yCord>19)
				return 0;
			
			// getTile Type helyes működés
			int id =   lvl[y/32][x/32];
			return this.getGame().getTileHandler().getTile(id).getTileType();
			
		}

	public void setLevel(int[][] lvl,PathPoint start,PathPoint end) {
		this.lvl = lvl;
		this.start= start;
		this.end = end;
	}
	private Tower getTowerAt(int x, int y) {
		return towerHandler.getTowerAt(x,y);
		
	}
	public TowerHandler getTowerHandler() {
		return towerHandler;
	}
	
	public void setSelectedTower(Tower selectedTower) {
		this.selectedTower= selectedTower;
		
	}
 
	public EnemyHandler getEnemyHandler() {
		return enemyHandler;
	}
	
	public WaveHandler getWaveHandler() {
		return waveHandler;
	}

	public boolean isGamePaused() {
		return gamePaused;
	}

	public void dmgPlayer(int dmgToPlayer) {
		actionbar.dmgPlayer(dmgToPlayer);
		
	}

	public void resetEverything() {
		actionbar.resetEverything();
		//Handlerek
		//ezekre lehet nincs szükség mostmár
		enemyHandler.reset();
		towerHandler.reset();
		projectileHandler.reset();
		waveHandler.reset();
		//Ez azért kell hogy teljesen újra kezdjük mint mikor létrejön a játék
		enemyHandler = new EnemyHandler(this,start,end);
		towerHandler = new TowerHandler(this);
		projectileHandler = new ProjectileHandler(this);
		waveHandler = new WaveHandler(this);
		
		//classon belül
		mouse_X = 0;
		mouse_Y = 0;
		
		selectedTower = null;
		gamePaused = false;
		
	}
}
