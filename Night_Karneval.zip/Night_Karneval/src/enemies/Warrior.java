package enemies;
import static helpz.Constants.Enemies.WARRIOR;

import handlers.EnemyHandler;
public class Warrior extends Enemy{

	public Warrior(float x, float y, int ID ,EnemyHandler enemyHandler) {
		super(x, y, ID, WARRIOR,enemyHandler);
	}

}
