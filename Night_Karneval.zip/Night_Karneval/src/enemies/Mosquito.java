package enemies;
import static helpz.Constants.Enemies.MOSQUITO;

import handlers.EnemyHandler;
public class Mosquito extends Enemy{

	public Mosquito(float x, float y, int ID,EnemyHandler enemyHandler) {
		super(x, y, ID, MOSQUITO,enemyHandler);
	}

}
