package enemies;
import static helpz.Constants.Enemies.SPRIGGAN;

import handlers.EnemyHandler;
public class Spriggan extends Enemy {

	public Spriggan(float x, float y, int ID,EnemyHandler enemyHandler) {
		super(x, y, ID, SPRIGGAN,enemyHandler);
	}

}
