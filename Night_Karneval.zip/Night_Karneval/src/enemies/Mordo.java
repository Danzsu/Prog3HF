package enemies;
import static helpz.Constants.Enemies.MORDO;

import handlers.EnemyHandler;
public class Mordo extends Enemy {

	public Mordo(float x, float y, int ID, EnemyHandler enemyHandler) {
		super(x, y, ID, MORDO,enemyHandler);
	}

}
