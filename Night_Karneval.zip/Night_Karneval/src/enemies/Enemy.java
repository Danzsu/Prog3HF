package enemies;

import handlers.EnemyHandler;
import static helpz.Constants.Direction.*;
import java.awt.Rectangle;

//Az Enemy osztály az összes ellenség osztályának ősosztálya
//Az ellenségek közös tulajdonságait és metódusait tartalmazza
//Az ellenségek közös tulajdonságai: pozíció, életerő, sebesség, irány, típus, utolsó irány, életben van-e
//Az ellenségek közös metódusai: mozgás, sebzés, lassítás, életerő arányának lekérdezése, életerő beállítása, jutalom adása a játékosnak ha az ellenség meghal


public abstract class  Enemy {
	protected EnemyHandler enemyHandler;
	protected float x,y;
	protected Rectangle bounds; // ez a hitbox miatt kell majd
	protected int health;
	protected int maxHealth;
	protected int ID;
	protected int enemy_type;
	protected int lastDir;
	protected boolean alive = true;
	protected int slowTickLimit = 60*2; // 60 szor frissítünk a gamen másodperceként szóval 2 azt mutatja hany mp ig tartson
	protected int slowTick =slowTickLimit;

	//Konstruktor a pozíció, azonosító, típus és az enemyHandler beállításához
	public Enemy(float x,float y,int ID,int enemy_type,EnemyHandler enemyHandler) {
		this.x=x;
		this.y=y;
		this.ID=ID;
		this.enemy_type=enemy_type;
		this.enemyHandler=enemyHandler;
		bounds = new Rectangle((int)x,(int)y,32,32);
		lastDir = -1;
	
		setStarthealth();
	}
	//Ezzel állítjuk be az egyes enemy Typeoknak a kezdő életerejét 
	private void setStarthealth() {
		health = helpz.Constants.Enemies.GetStartHealth(enemy_type);
		maxHealth=health;
	}
	//Az ellenség sebzésére szolgáló metódus ez csökkenti az életerejét és ellenőrzi hogy meghalt-e ha igen akkor jutalmat ad a játékosnak
	public void hurt (int dmg) {
		this.health -=dmg;
		if(health <=0) {
			alive = false;
			enemyHandler.rewardPlayer(enemy_type);
		}
	}
	//Az ellenség sebzése a játékosra
	public int getDmgToPlayer() {
		return helpz.Constants.Enemies.GetDmgToPlayer(enemy_type);
	}
	
	public void slow() {
		slowTick = 0;
		
	}
	//Az ellenség mozgását szabályozó metódus
	public void move(float speed,int dir) {
		lastDir = dir;
		if(isSlowed()) { //slowTick < slowTickLimit
			slowTick++;
			speed *=0.5f;
		}
		switch(dir) {
		case LEFT:
			this.x -=speed; // -1 mert balra megy tehát csökkenteni kell az x-et
			break;
		case UP:
			this.y -=speed;// -1 mert felfelé megy tehát csökkenteni kell az y-t
			break;
		case RIGHT:
			this.x +=speed;// +1 mert jobbra megy tehát növelni kell az x-et
			break;
		case DOWN:
			this.y +=speed;// +1 mert lefelé megy tehát növelni kell az y-t
			break;
		}
		updateHitbox();// a hitbox frissítése a pozíció változásával
	}
	//Az ellenség körülbelüli pozíciójának frissítése ahol projektillel ütközhet
	private void updateHitbox() {
		bounds.x=(int) x;
		bounds.y = (int) y;
	}

	//GETTER & SETTER & lekérdező metódusok

	public float getHealthBarRatio() {
		return (float) health / (float) maxHealth;
	}
	public float getX() {
		return x;
	}

	public void setPos(int x,int y) {
		// nem mozgatáshoz van hanem a megfelelő pozíció beállításhoz a move nak
		this.x = x;
		this.y = y;
	}

	public float getY() {
		return y;
	}


	public Rectangle getBounds() {
		return bounds;
	}



	public int getHealth() {
		return health;
	}

	public int getID() {
		return ID;
	}


	public int getEnemy_type() {
		return enemy_type;
	}
	public int getLastDir() {
		return lastDir;
	}
	
	public boolean isAlive() {
		return alive;
	}
	//Az ellenség életét nullázó metódus és megöli az ellenséget
	public void killEnemy() {
		alive = false;
		health = 0;
	}
	public void resetLastDir() {
		lastDir = -1;
	}
	public void setLastDir(int Dir) {
		lastDir = Dir;
	}
	
	public boolean isSlowed() {
		return slowTick < slowTickLimit;
	}
	
}
