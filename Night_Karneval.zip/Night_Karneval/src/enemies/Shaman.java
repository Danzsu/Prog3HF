package enemies;
import static helpz.Constants.Enemies.SHAMAN;

import handlers.EnemyHandler;

public class Shaman extends Enemy {

	public Shaman(float x, float y, int ID,EnemyHandler enemyHandler) {
		super(x, y, ID, SHAMAN,enemyHandler);
	}

}
