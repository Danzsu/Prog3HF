package ui;

import java.awt.Color;
import java.awt.Graphics;

//Lehetne abstract is de nem muszáj
public class Bar {
	protected int x,y,width,height;
	// hozzá kell tudni férni a leszármazott osztályoknak is
	public Bar(int x,int y,int width,int height) {
		this.x=x;
		this.y=y;
		this.width=width;
		this.height = height;
	}
	// azt szeretnénk hogy örököljük ezt így ne kelljen a Toolbarba és az Actionbarba külön-külön implementálni
	// örököljék ezt a függvényt
	protected void drawButtonFeedback(Graphics g, MyButton b) {
		//MouseOver
		if(b.isMouseOver()) {
			g.setColor(Color.white);
		}else {
			g.setColor(Color.black);
		}
		
		//Border állítás
		g.drawRect(b.x, b.y, b.width, b.height);
		
		
		//MousePressed
		if(b.isMousePressed()) {
			g.setColor(Color.MAGENTA);
			g.drawRect(b.x+1, b.y+1, b.width-2, b.height-2);
			g.drawRect(b.x+2, b.y+2, b.width-4, b.height-4);
			
		}
	}
}
