package ui;

import static main.GameStates.MENU;
import static main.GameStates.setGameState;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import helpz.LoadSave;
import objects.Tile;
import scenes.Editing;
//A ToolBar osztály felelős a játékban a szerkesztői eszköztár megjelenítéséért és a szerkesztői eszköztár működéséért
//Az Editing GameState-ben jelenik meg és a játék szerkesztéséhez szükséges eszközöket tartalmazza
public class ToolBar extends Bar {
	private Editing editing;
	private MyButton b_Menu,b_Save;
	
	private Tile selectedTile;
	
	// régebbi megoldás private ArrayList<MyButton> tileButtons = new ArrayList<>();
	private Map<MyButton,ArrayList<Tile>> map = new HashMap<MyButton,ArrayList<Tile>>();

	private MyButton bGrass,bWater,bRoadS,bRoadC,bWaterC,bWaterM,bDecors;
	private MyButton bPathStart,bPathEnd;
	private BufferedImage pathStart,pathEnd;//csakis 1-1 lehet letéve belőle
	private MyButton currentButton;
	private int currentIndex=0;
	
	public ToolBar(int x, int y, int width, int height,Editing editing) {
		super(x, y, width, height);
		this.editing=editing;
		initPathImgs();
		initButtons();
	}
	private void initPathImgs() {
		pathStart = LoadSave.getSpriteBeta().getSubimage(8*32, 5*32, 32, 32);
		pathEnd = LoadSave.getSpriteBeta().getSubimage(9*32, 5*32, 32, 32);
		
	}
	private void initButtons() {	
		b_Menu =new MyButton("Menu",2,642,100,30);
		b_Save = new MyButton("Save",2,674,100,30);
		
		int w = 50;
		int h = 50;
		int xStart= 110;
		int yStart= 650;
		int nextDist = (int)(w*1.1); // következő buttom távolsága az előzőtől
		int i = 0; 
		// egyben iterálásban is segít és az id-t is ő képzi
		
		
		bGrass = new MyButton("Grass",xStart,yStart,w,h,i++);
		bWater = new MyButton("Water",xStart+nextDist,yStart,w,h,i++);
		
		//az editing menu ből lekérjök a játékot az ahhoz tartozó TileHandler-t és az adott tile listát
		// 			  button  , lista amiben benne vannak a forgatható tileok, x,     y,	  offset,   w, h, id
		initMapButton(bRoadS, editing.getGame().getTileHandler().getRoadsS(), xStart, yStart, nextDist, w, h, i++);
		initMapButton(bRoadC, editing.getGame().getTileHandler().getRoadsC(), xStart, yStart, nextDist, w, h, i++);
		initMapButton(bWaterC, editing.getGame().getTileHandler().getWcorners(), xStart, yStart, nextDist, w, h, i++);
		initMapButton(bWaterM, editing.getGame().getTileHandler().getWmiddle(), xStart, yStart, nextDist, w, h, i++);
		initMapButton(bDecors, editing.getGame().getTileHandler().getDecors(), xStart, yStart, nextDist, w, h, i++);
		bPathStart = new MyButton("PathStart", xStart, yStart+nextDist, w, h,i++);
		bPathEnd = new MyButton("PathEnd", xStart+nextDist, yStart+nextDist, w, h,i++);
		/* régi megoldás amikor listában tároltam
		for(Tile tile : editing.getGame().getTileHandler().tiles) {
			tileButtons.add(new MyButton(tile.getName(),xStart+ x_next_dist*i,yStart,w,h,i));
			i++;
		}*/
	}
	private void initMapButton(MyButton b,ArrayList<Tile> list,int x, int y, int xDist,int w,int h,int id) {
		b = new MyButton("",x + xDist*id,y,w,h,id);
		map.put(b, list);
		// itt a b a kulcs tehát maga a button a kulcs és a list az érték, a lista elemeit így fogjuk elérni map.get(b) és itt a map.get(b) már az adott lista
		// így olyan mintha tiles. lenne
		
	}
	
	// a jelenlegi tile-t mentjük el
	private void saveLevel() {
		editing.saveLevel();
	}
	// A kiválasztott tile-t állítjuk be
	public void nextSprite() {
		
		currentIndex++;
		//ha túl mennénk az indexen állítsuk vissza 0 ra így a kiinduló Tile-t kapjuk meg
		if(currentIndex >= map.get(currentButton).size())
			currentIndex = 0;
		selectedTile = map.get(currentButton).get(currentIndex);
		editing.setSelectedTile(selectedTile);
		}
	
	///DRAWING METHODS
	public void draw(Graphics g) {
		//background
		g.setColor(new Color(220,123,15));
		g.fillRect(x, y, width, height);
		
		//Buttons
		drawButtons(g);
	}
	
	private void drawButtons(Graphics g) {
		b_Menu.draw(g);
		b_Save.draw(g);
		
		drawPathButton(g,bPathStart,pathStart);
		drawPathButton(g,bPathEnd,pathEnd);
		
		drawNormalButtons(g,bGrass);
		drawNormalButtons(g,bWater);
		drawSelectedTile(g);
		drawMapButtons(g);
	}
	
	private void drawPathButton(Graphics g, MyButton b, BufferedImage img) {
		g.drawImage(img, b.x, b.y,b.width, b.height, null);
		drawButtonFeedback(g,b);
		
	}
	private void drawNormalButtons(Graphics g, MyButton b) {
		//Gomb kirajzolása
		g.drawImage(getButtImg(b.getId()),b.x, b.y, b.width, b.height, null);
		//a különböző egérrel való interakciók beállítása
		drawButtonFeedback(g,b);
	}
	private void drawMapButtons(Graphics g) {
		// itt 3 lehetőség is van hogy a kulcs szerint vagy a listák szerint megyek végig vagy egyszerre mindkettő
		//itt most az entry lesz az egyes gombok
		for(Map.Entry<MyButton, ArrayList<Tile>> entry : map.entrySet()) {
			MyButton b = entry.getKey();
			BufferedImage img = entry.getValue().get(0).getSprite();

			// előző megoldásból --> egyszerűbb b ben eltárolni mert átláthatóbb
			// g.drawImage(entry.getValue().get(0).getSprite(),entry.getKey().x,entry.getKey().y,
			//									entry.getKey().width.entry.getKey().height,null);

			//Gomb kirajzolása
			g.drawImage(img, b.x, b.y, b.width, b.height, null);
			
			//a különböző egérrel való interakciók beállítása
			drawButtonFeedback(g,b);
			
		}			
	}
	
	
	private void drawSelectedTile(Graphics g) {
		if(selectedTile!=null) {
			g.drawImage(selectedTile.getSprite(),550, 650, 50, 50, null);
			g.setColor(new Color(232,30,99));
			g.drawRect(550, 650, 50, 50);
			g.drawRect(551, 651, 48, 48);
			g.drawRect(552, 652, 46, 46);
		}
	}
	private BufferedImage getButtImg(int id) {
		return editing.getGame().getTileHandler().getSprite(id);
	
	}
	
	// MOUSE EVENTS HANDLED
	//A gombokra való kattintásokat kezeli és a gombokra való egérrel való mozgást
	public void mouseClicked(int x, int y) {
		if(b_Menu.getBounds().contains(x, y)) {
			setGameState(MENU);
		}
		else if(b_Save.getBounds().contains(x,y)) {
			saveLevel();
		}
		else if(bWater.getBounds().contains(x,y)) {
			selectedTile = editing.getGame().getTileHandler().getTile(bWater.getId());
			editing.setSelectedTile(selectedTile);
			return;
		}
		else if(bGrass.getBounds().contains(x,y)) {
			selectedTile = editing.getGame().getTileHandler().getTile(bGrass.getId());
			editing.setSelectedTile(selectedTile);
			return;
		}
		else if(bPathStart.getBounds().contains(x,y)) {
			selectedTile = new Tile(pathStart,-1,-1);
			editing.setSelectedTile(selectedTile);
			return;
		}
		else if(bPathEnd.getBounds().contains(x,y)) {
			selectedTile = new Tile(pathEnd,-2,-2);
			editing.setSelectedTile(selectedTile);
			return;
		}
		else {
			for (MyButton b : map.keySet()) 
				if(b.getBounds().contains(x,y)) {
					selectedTile = map.get(b).get(0);
					editing.setSelectedTile(selectedTile);
					currentButton = b; // beállítjuk az adott key nek megfelelő button a jelenlegi button re
					currentIndex = 0; // visszaállítjuk az indexet
					return;
				}
			
		}

	}

	
	
	public void mouseMoved(int x, int y) {
		b_Menu.setMouseOver(false);
		b_Save.setMouseOver(false);
		bGrass.setMouseOver(false);
		bWater.setMouseOver(false);
		bPathEnd.setMouseOver(false);
		bPathStart.setMouseOver(false);

		
		for (MyButton b : map.keySet()) {
			b.setMouseOver(false);
		}
		//ellenőrizni hogy gombot érintettünk e
		if(b_Menu.getBounds().contains(x, y)) {
			b_Menu.setMouseOver(true);
		}
		else if(b_Save.getBounds().contains(x,y)) {
			b_Save.setMouseOver(true);
		}
		else if(bGrass.getBounds().contains(x,y)) {
			bGrass.setMouseOver(true);
		}
		else if(bWater.getBounds().contains(x,y)) {
			bWater.setMouseOver(true);
		}
		else if(bPathStart.getBounds().contains(x,y)) {
			bPathStart.setMouseOver(true);
		}
		else if(bPathEnd.getBounds().contains(x,y)) {
			bPathEnd.setMouseOver(true);
		}
		else {
			for (MyButton b : map.keySet()) 
				if(b.getBounds().contains(x,y)) {
					b.setMouseOver(true);
					return;
				}
			
			
		}
	}

	public void mousePressed(int x, int y) {
		if(b_Menu.getBounds().contains(x, y)) {
			b_Menu.setMousePressed(true);
		}
		else if(b_Save.getBounds().contains(x,y)) {
			b_Save.setMousePressed(true);
		}
		else if(bGrass.getBounds().contains(x,y)) {
			bGrass.setMousePressed(true);
		}
		else if(bWater.getBounds().contains(x,y)) {
			bWater.setMousePressed(true);
		}
		else if(bPathStart.getBounds().contains(x,y)) {
			bPathStart.setMousePressed(true);
		}
		else if(bPathEnd.getBounds().contains(x,y)) {
			bPathEnd.setMousePressed(true);
		}
		else {
			for (MyButton b : map.keySet()) 
				if(b.getBounds().contains(x,y)) {
					b.setMousePressed(true);
					return;
				}	
		}
	}
	
	public void mouseReleased(int x, int y) {
		resetButtons();
		
	}
	
	private void resetButtons() {
		b_Menu.resetBool();
		b_Save.resetBool();
		bWater.resetBool();
		bGrass.resetBool();
		bPathStart.resetBool();
		bPathEnd.resetBool();
		
		for (MyButton b : map.keySet()) 
				b.resetBool();
			
		
	}
	
	/// GETTER & SETTER 
	public BufferedImage getStartPathImg() {
		return pathStart;
	}
	public BufferedImage getEndPathImg() {
		return pathEnd;
	}
	
}