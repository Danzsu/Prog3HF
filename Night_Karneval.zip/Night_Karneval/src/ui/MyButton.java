package ui;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class MyButton {
	public int x, y, width, height,id;
	// az egyértelműbb elérhetőség miatt lett public lehetne getter setterel is de átláthatatlannábbá válna
	private String text;
	
	private Rectangle bounds; // az egér pozíciójának ellenőrzésére kel hogy a négyzeten belül van e
	private boolean mouseOver,mousePressed;
	
	// Sima gombokra ezt használom
	public MyButton(String text,int x , int y , int width, int height) {
		this.text = text;
		this.x = x;
		this.y=y;
		this.width=width;
		this.height= height;
		this.id= -1;
		initBounds();
	}
	
	// Tile gombokra ezt használom ... még egy konstruktor az id miatt így nem kell mindegyiknek megadni id-t csak ahol hasznos
	public MyButton(String text,int x , int y , int width, int height,int id) {
		this.text = text;
		this.x = x;
		this.y=y;
		this.width=width;
		this.height= height;
		this.id=id;
		initBounds();
	}
	
	//a határok inicializálására kell
	private void initBounds() {
		this.bounds= new Rectangle(x,y,width,height);
	}
	
	// ez az ami a gombot kirajzolja
	public void draw(Graphics g) {
		//Body
		drawBody(g);
		
		
		//Border
		drawBorder(g);
		
		
		//Text
		drawText(g);	
	}
	public void setText(String text ) {
		this.text = text;
	}
	// a gomb keretét rajzolja ki
	private void drawBorder(Graphics g) {
		g.setColor(Color.black);
		g.drawRect(x, y, width, height);
		if(mousePressed) {
			g.drawRect(x+1, y+1, width-2, height-2);
			g.drawRect(x+2, y+2, width-4, height-4);
		}
		
		
	}

	private void drawBody(Graphics g) {
		if(mouseOver) {
			g.setColor(Color.gray);
		}
		else {
			g.setColor(Color.white);
		}
	
		g.fillRect(x, y, width, height);
		
	}
	// a gomb szövegét rajzolja ki
	private void drawText(Graphics g) {
		int w_text= g.getFontMetrics().stringWidth(text); // lekérdezzük a Font típusát ls így annak a szélességét is 
		int h_text = g.getFontMetrics().getHeight(); // lekérdezzük a Font típusát és annak a magasságát
		g.drawString(text, x - w_text/2 + width/2, y + h_text/3 + height/2);
		// így mostmár középre lesz igazítva a szöveg
		
	}
	public void setMousePressed(boolean mousePressed) {
		this.mousePressed = mousePressed;
	}
	public void setMouseOver(boolean mouseOver) {
		this.mouseOver = mouseOver;
	}
	public void resetBool() {
		this.mouseOver=false;
		this.mousePressed=false;
	}
	
	//bool getterek ami a pályaszerkesztésnél a gombokhoz kell, hogy interaktálható legyen
	public boolean isMouseOver() {
		return mouseOver;
	}
	public boolean isMousePressed() {
		return mousePressed;
	}
	
	// a gombok méretének érzékeléséhez kellenek Lényegében négyzeteket használunk
	public Rectangle getBounds() {
		return bounds;
	}
	//azért van hogy a tile-okat megtudjuk kölönböztetni és így kitudjuk rajzolni őket
	public int getId() {
		return id;
	}
}
