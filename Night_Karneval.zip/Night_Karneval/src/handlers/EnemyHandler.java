package handlers;

import enemies.Enemy;
import enemies.Mordo;
import enemies.Mosquito;
import enemies.Shaman;
import enemies.Spriggan;
import enemies.Warrior;
import static helpz.Constants.Direction.*;
import static helpz.Constants.Enemies.*;
import static helpz.Constants.Tiles.*;
import helpz.LoadSave;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import objects.PathPoint;
import scenes.Playing;

public class EnemyHandler {
	
	private Playing playing;
	private BufferedImage[] enemyImgs;
	private ArrayList<Enemy> enemies= new ArrayList<>();
	private PathPoint start,end;
	private final int enemynmb = 5; //itt 5 db ellenfelet jelent ez később lehet bővíteni
	private int HpBarWidth = 24;
	private BufferedImage slowEffect;
	
	

	public EnemyHandler(Playing playing,PathPoint start,PathPoint end) {
		this.playing = playing;
		enemyImgs = new BufferedImage[enemynmb]; 
		this.start = start;
		this.end = end;
		
		loadEffectImg();
		
		loadEnemyImgs();
	}
	//
	//TODO path makingel baj van ha a start blokk a pálya bal szélén van vagy teteljén először kimennek de vissza jönnek
	//így lett megoldva
	
	
	private void loadEffectImg() {
		slowEffect= LoadSave.getSpriteBeta().getSubimage(7*32, 0*32, 32, 32);
		
	}

	
	private void loadEnemyImgs() {
		BufferedImage beta = LoadSave.getSpriteBeta();
		//itt addjuk hozzá az enemy képeit
		for(int i =0;i<enemynmb ; i++) {
			enemyImgs[i] = beta.getSubimage((i+5)*32, 9*32, 32, 32);
		}
		enemyImgs[3] = beta.getSubimage(3*32, 9*32, 32, 32);
		
	}

	public void update() {
		for(Enemy e: enemies) 
			// a következő tile út vagy nem (pos, dir)
			if(e.isAlive())
					UpdateEnemyMove(e);
	}

	//Azért kell hogy tudjuk az ellenségeket mozgatni, felismerjük a következő tile-t
	//ha az út akkor megy tovább ha nem akkor új irányba megy
	//ha a vég ponton van akkor meghal és sebződik a játékos 
	public void UpdateEnemyMove(Enemy e) {
	
		if(e.getLastDir()==-1) {
			setNewDirectionAndMove(e);
		}		
		
		int newX =(int)  (e.getX() + getSpeedAndWidth(e.getLastDir(),e.getEnemy_type()));
		int newY = (int) (e.getY() + getSpeedAndHeight(e.getLastDir(),e.getEnemy_type()));
		
		if(getTileType(newX,newY)==ROAD_TILE) {
			e.move(GetSpeed(e.getEnemy_type()), e.getLastDir());
			// mozgás ugyanabba az irányba
		}else if(isAtEnd(e)) {
			e.killEnemy();
			playing.dmgPlayer(e.getDmgToPlayer());
			} 	
		
		 
		
		else {
			//új irányba mozgás
			setNewDirectionAndMove(e);
		}
	
	}
//Path making függvény
//Azért kell hogy a következő tile-t megtudjuk határozni
//Ha a következő tile út akkor megy tovább ha nem akkor új irányba megy
//Ha a vég ponton van akkor meghal és sebződik a játékos 
	public void setNewDirectionAndMove(Enemy e) {
		int dir = e.getLastDir();
		e.setLastDir(dir);
		// correction to get into the current tile for sure
		int xCord = (int) e.getX()/32;
		int yCord = (int) e.getY()/32;
		fixEnemyOffsetTile(e,dir,xCord,yCord);
		// ha a vég ponton van akkor viszont nem mozog
		if(isAtEnd(e)==true) {
			return;
		}
		// ha a jelenlegi irányban tud mozogni akkor megy tovább ha nem akkor új irányba megy
		if(dir == LEFT || dir == RIGHT ) {
			int newYU = (int) (e.getY() + getSpeedAndHeight(UP,e.getEnemy_type()));
			int newYD = (int) (e.getY() + getSpeedAndHeight(DOWN,e.getEnemy_type()));
			if(getTileType((int) e.getX(),newYU) == ROAD_TILE) {
				e.move(GetSpeed(e.getEnemy_type()), UP);
				e.setLastDir(UP);
			}
			
			else if(getTileType((int) e.getX(),newYD) == ROAD_TILE) {
				e.move(GetSpeed(e.getEnemy_type()), DOWN);
				e.setLastDir(DOWN);
			}
			else {
				e.resetLastDir();
			//	System.out.println("RIGHT OR LEFT RESET "+e.getLastDir());
			}
		// ha a jelenlegi irányban tud mozogni akkor megy tovább ha nem akkor új irányba megy 		
	}else if(dir == DOWN || dir == UP) {
		int newXR = (int)  (e.getX() + getSpeedAndWidth(RIGHT,e.getEnemy_type()));
		int newXL = (int)  (e.getX() + getSpeedAndWidth(LEFT,e.getEnemy_type()));
		
		if(getTileType(newXR, (int) e.getY()) == ROAD_TILE) {
			e.move(GetSpeed(e.getEnemy_type()), RIGHT);
			e.setLastDir(RIGHT);
		}
			
		else if(getTileType(newXL, (int) e.getY()) == ROAD_TILE) {
			e.move(GetSpeed(e.getEnemy_type()), LEFT);
			e.setLastDir(LEFT);
		}
			
		else {
			e.resetLastDir();
		//	System.out.println("UP OR DOWN RESET "+e.getLastDir());
		}
			
	}
	else{//if(dir == -1) {
		//	System.out.println("Beléptem"+e.getLastDir());
		// ha az utolsó irány nem volt beállítva akkor beállítjuk vagy ha reseteljük
		//ilyenkor meg kell nézni hogy merre tud mozogni
		//ha nem tud akkor reseteljük az irányt
			int newYU = (int) (e.getY() + getSpeedAndHeight(UP,e.getEnemy_type()));
			int newYD = (int) (e.getY() + getSpeedAndHeight(DOWN,e.getEnemy_type()));
			int newXR = (int)  (e.getX() + getSpeedAndWidth(RIGHT,e.getEnemy_type()));
			int newXL = (int)  (e.getX() + getSpeedAndWidth(LEFT,e.getEnemy_type()));
			
			if(getTileType((int) e.getX(),newYU) == ROAD_TILE && (int)e.getY() >= 32  ) { //&&(int)e.getY()> 32
				e.move(GetSpeed(e.getEnemy_type()), UP);
				e.setLastDir(UP);
			//	System.out.println("UP "+e.getLastDir());
			}
			else if(getTileType((int) e.getX(),newYD) == ROAD_TILE && (int)e.getY() <= 800 ) {
				e.move(GetSpeed(e.getEnemy_type()), DOWN);
				e.setLastDir(DOWN);
			//	System.out.println("DOWN "+e.getLastDir());
			}
			
			else if(getTileType(newXR, (int) e.getY()) == ROAD_TILE   &&(int)e.getY()< 800) {
				e.move(GetSpeed(e.getEnemy_type()), RIGHT);
				e.setLastDir(RIGHT);
				//System.out.println("RIGHT "+e.getLastDir());
			}
			
			else if(getTileType(newXL, (int) e.getY()) == ROAD_TILE   &&(int)e.getY()>= 32 ) { //&& (int)e.getX() >= 32 
				e.move(GetSpeed(e.getEnemy_type()), LEFT );
				e.setLastDir(LEFT);
			//	System.out.println("LEFT "+e.getLastDir());
			}
				
				
		}
		
	}
	// arra van hogy mindig pontosan a Tile on legyen az enemy amikor mozgatjuk ne lógjon le
	
	private void fixEnemyOffsetTile(Enemy e,int dir, int xCord, int yCord) {
		switch(dir) {
		/*case LEFT:
			if(xCord ==0 )
				xCord++;
			else
				xCord--;
		
			break;
		case UP:
			if(yCord >19)
				yCord=19;
			else if(yCord ==0)
				yCord=0;
			break;
			*/
			
		case RIGHT:
			if(xCord <19 && xCord >=0)
				xCord++;
			else
				xCord--;
			break;
			
			
		case DOWN:
			if(yCord <19 && yCord >=0)
				yCord++;
			else
				yCord--;
			
			break;
		}
		e.setPos(xCord*32,yCord*32);
	}
	//ha az ellenség a vég ponton van akkor vissza adja az igazat
	public boolean isAtEnd(Enemy e) {
		if( e.getX() == end.getxCord()*32) {
			if( e.getY() == end.getyCord()*32) {
				return true;
			}
		}
		return false;
	}

	private int getTileType(int x, int y) {
		return playing.getTileType(x,y);
	}
///TODO Van hogy kimegy a pályáról de visszajön ez amiatt van hogy néha nem tudja fixálni a pozíciót nem találtam rá megoldást
	private float getSpeedAndHeight(int dir,int enemyType) {
		if(dir == UP)
			return -GetSpeed(enemyType);	
		else if(dir == DOWN)
			return GetSpeed(enemyType)+32;
		return 0;
	}
	private float getSpeedAndWidth(int dir,int enemyType) {
		if(dir== LEFT)
			return -GetSpeed(enemyType);// x tengelyen a - balra
		
		else if (dir == RIGHT)// x tengelyen + jobbra
			return GetSpeed(enemyType)+32 ;
		
		return 0;
	}
	public void spawnEnemy(int nextEnemy) {
		addEnemy(nextEnemy);
		
	}
	//Hozzáadja az ellenséget a listához
	public void addEnemy(int enemyType) {
		
		int x = start.getxCord()*32;
		int y = start.getyCord()*32;
		int id = 0;
		switch(enemyType) {
		case WARRIOR:
			enemies.add(new Warrior(x,y,id++,this));
			break;
		case SHAMAN:
			enemies.add(new Shaman (x,y,id++,this));
			break;
		case MORDO:
			enemies.add(new Mordo(x,y,id++,this));
			break;
		case MOSQUITO:
			enemies.add(new Mosquito(x,y,id++,this));
			break;
		case SPRIGGAN:
			enemies.add(new Spriggan(x,y,id++,this));
			break;
		}
	
	}
	public void draw(Graphics g) {
		for (Enemy e : enemies) {
			if(e.isAlive()) {
				drawEnemy(e,g);
				drawHealthBar(e,g);
				drawEffects(e,g); // lassító effektet rárajzoljuk
			}
		}
	}// lassító effektet rajzoljuk rá az ellenségre ha lassítva van 
	private void drawEffects(Enemy e, Graphics g) {
		if(e.isSlowed())
			g.drawImage(slowEffect, (int) e.getX(), (int) e.getY(), null);
			
		
	}

	//rajzolja az életerő sávot az ellenségek felett
	private void drawHealthBar(Enemy e, Graphics g) {
		g.setColor(new Color(232,30,99));
		g.fillRect( (int) e.getX() + 16 -(getNewBarWidth(e)/2), (int) e.getY()-5, getNewBarWidth(e), 3);
		// középre igazítás hozzáadok egy tilenak a felét ami 16
		// kivonom belőle a HpBarWidth felét
	}
	private int getNewBarWidth(Enemy e) {
		return (int) (HpBarWidth * e.getHealthBarRatio());
	}
	private void drawEnemy(Enemy e, Graphics g) {
		g.drawImage(enemyImgs[e.getEnemy_type()], (int) e.getX(), (int) e.getY(), null);
		
	}

	public ArrayList<Enemy> getEnemies(){
		return enemies;
	}

	//Megnézi hogy az összes ellenség él e
	public int getAmountOfAliveEnemies() {
		int size = 0;
		for(Enemy e :  enemies) {
			if(e.isAlive())
				size++;	
		}
		return size;
	}


	public void rewardPlayer(int enemy_type) {
		playing.rewardPlayer(enemy_type);
		
	}

	public void reset() {
		enemies.clear();
	}
	
	
	
}
