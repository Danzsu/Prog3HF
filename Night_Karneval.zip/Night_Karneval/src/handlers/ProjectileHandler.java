package handlers;

import enemies.Enemy;
import static helpz.Constants.Projectiles.*;
import static helpz.Constants.Towers.*;
import helpz.LoadSave;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import objects.Projectile;
import objects.Tower;
import scenes.Playing;

public class ProjectileHandler {
	private Playing playing;
	private ArrayList<Projectile> projectileList = new ArrayList<>();
	private ArrayList<Explosion> explosionList = new ArrayList<>();
	private BufferedImage[] projImgs,explosionImgs;
	private int projID =0;

	
	public ProjectileHandler(Playing playing){
		this.playing = playing;
		importImgs();

	}
	// A képek betöltése a spriteból a projektiloknak
	private void importImgs() {
		BufferedImage beta = LoadSave.getSpriteBeta();
		projImgs = new BufferedImage[3];
		
		for(int i =0;i<3;i++) {
			projImgs[i] = beta.getSubimage(i*32, 1*32, 32, 32);
		}
		projImgs[2] = beta.getSubimage(8*32, 0, 32, 32);
		importExplosion(beta);
	}

	///TODO magyarázd el hogyan működik a projectile
	// egyszerűbb Tower és Enemy paraméterrel hiszen úgyis tőlük függően fogjuk létrehozni
	
	private void importExplosion(BufferedImage beta) {
		explosionImgs = new BufferedImage[7];
		for(int i=0;i<explosionImgs.length;i++) {
			explosionImgs[i]=beta.getSubimage((3+i)*32, 32, 32, 32);
		}
		
	}
	// A projectileok létrehozása a tornyokból kiindulva és az ellenségek felé
	public void newProjectile(Tower t,Enemy e) {
		int type = getProjType(t);
		int xDist = (int) (t.getX()-e.getX());
		int yDist = (int) (t.getY()-e.getY());
		int totalDist = Math.abs(xDist) + Math.abs(yDist);
		
		float xRatio = (float) Math.abs(xDist)/totalDist;
		
		//A sebesség beállítása a projectileoknak
		float xSpeed = xRatio* helpz.Constants.Projectiles.GetSpeed(type);
		float ySpeed= helpz.Constants.Projectiles.GetSpeed(type) - xSpeed;
		
		//Ha az ellenség a tornyó felett van akkor a sebesség negatív lesz
		if(t.getX()>e.getX())
			//Balra kell menni
			xSpeed *=-1;
		if(t.getY()>e.getY())
			ySpeed *=-1;
		
		float rotate = 0;
		if(type == ARROW) {
			//Math.atan visszadja egy tangens szögét radiánba
			//Math.toDegrees átváltja radiánból fokba
			float arcValue = (float) Math.atan(yDist/ (float) xDist);
			rotate = (float) Math.toDegrees(arcValue);
			
			if(xDist<0)
				rotate +=180;
		}		
		//optimalizálás hogy kevésbé legyen erőforrásigényes
		//Megkeressük hogy van e azonos típusú projectile ami már inaktív és azt írjuk felül
		//Másik megoldás hogy removeoljuk amikor deaktiváljuk de sztem a felülírás gyorsabb
		//Ha nincs akkor újat hozunk létre
		for(Projectile p : projectileList) {
			if(!p.isActive())
				if(p.getProjectileType()==type) {
					p.reuse(t.getX()+16,t.getY()+16,xSpeed,ySpeed,t.getDmg(),rotate);
					return;
				}
		}
		
		projectileList.add(new Projectile(t.getX()+16,t.getY()+16,xSpeed,ySpeed,t.getDmg(),rotate,projID++,type));
	}
	//A projectileok mozgatása és az ellenségek sebzése ha talál a projectile
	public void update() {
		///TODO Lassan kezeli le azt amikor úgy teszem le a tornyot hogy már több ellenség is van a területén belül
		for(Projectile p : projectileList)
			if(p.isActive()) {
				p.move();
				if(isProjHitEnemy(p)) {
					if(p.getProjectileType() == BOMB) {
						explosionList.add(new Explosion(p.getPos()));
						explodeOnEnemise(p);
					}
					
					p.setActive(false);		
				}else if(isProjecOutsideBounds(p)){//ha kimegy a pályáról akkor deaktiváljuk
					p.setActive(false);
				}
				
			}
			//Az explosionokat is frissíteni kell
		for(Explosion ex : explosionList) {
			if(ex.getExploIndex()<7)
				ex.update();
		}
		
				
	}
	private boolean isProjecOutsideBounds(Projectile p) {
		if(p.getPos().x >= 0)
			if(p.getPos().x <= 640)
				if(p.getPos().y >= 0)
					if(p.getPos().y <= 800)
						return false;
		return true;
	}
	//Megnézi hogy a projectile eltalálta e az ellenséget
	//Ha igen akkor sebez rajta és visszaadja hogy talált e
	public boolean isProjHitEnemy(Projectile p) {
		for(Enemy e : playing.getEnemyHandler().getEnemies()) {
			if(e.isAlive()) 
				if(e.getBounds().contains(p.getPos())) {//ha a projectile a ellenség területén belül van akkor sebez
					e.hurt(p.getDmg());
					if(p.getProjectileType() == MAGIC)
						e.slow();
					
					return true;
				}
		}
		return false;
	}		
	///
	///TODO Lassan kezeli le azt amikor úgy teszem le a tornyot hogy már több ellenség is van a területén belül
	///
	//Az ellenségeken belül keresi meg azokat akik a bomba hat rádiuszán belül vannak és sebez rajtuk 
	private void explodeOnEnemise(Projectile p) {
		for(Enemy e : playing.getEnemyHandler().getEnemies()) {
			if(e.isAlive()) {
			float radius = 100.0f;
			
			float xDist = Math.abs(p.getPos().x - e.getX());
			float yDist = Math.abs(p.getPos().y - e.getX());
			
			float realDist = (float) Math.hypot(xDist, yDist); // átfogó
			
			if(realDist <= radius) {
				e.hurt(p.getDmg());
				}
			}
		}
		
	}
	
	public void draw(Graphics g) {
		//azért kell hogy tudjuk használni a Graphics2D függvényeit
		Graphics2D g2d = (Graphics2D) g;
	  
		for(Projectile p : projectileList) {
			//csak azért hogy a projectileok ne tudjanak kimenni a pályáról
			if(p.getPos().x >= 20*32-1 || p.getPos().y >= 20*32-1 ||  p.getPos().x <= 1 || p.getPos().y <= 1 )
				p.setActive(false);
			//ha aktív akkor rajzoljuk ki a képernyőre
			if(p.isActive()) {
				if(p.getProjectileType()==ARROW) {
					g2d.translate(p.getPos().x, p.getPos().y);
					g2d.rotate(Math.toRadians(p.getRotation()));
					g2d.drawImage(projImgs[p.getProjectileType()], -16, -16, null);
					g2d.rotate(-Math.toRadians(p.getRotation()));
					g2d.translate(-p.getPos().x, -p.getPos().y);
				}else {
					g2d.drawImage(projImgs[p.getProjectileType()], (int) p.getPos().x-16, (int) p.getPos().y-16, null);
				}
				drawExplosions(g2d);
			}
		
		}
		
	
		
	}//az explosionokat is ki kell rajzolni 
	private void drawExplosions(Graphics2D g2d) {
		for(Explosion e : explosionList) 
			if(e.getExploIndex() < 7) {
				g2d.drawImage(explosionImgs[e.getExploIndex()],(int) e.getPos().x-16, (int) e.getPos().y-16, null);
			
		}
		
	}

	// GETTERS & SETTERS
	private int getProjType(Tower t) {
		switch(t.getTowerType()) {
		case ARCHER:
			return ARROW;
		case CANNON:
			return BOMB;
		case WIZARD:
			return MAGIC;
		}
		return 0;
	}
	//INNER CLASSES
	//Az explosionokat is kezelni kell ezért egy külön osztályba raktam 
	// Az exploTick azért kell hogy a képek ne menjenek túl gyorsan
	//Az exploIndex azért kell hogy a képek sorrendje megfelelő legyen 
	public class Explosion{
		private Point2D.Float pos;
		private int exploTick = 0;
		private int exploIndex = 0;
		
		public Explosion(Point2D.Float pos) {
			this.pos = pos;
		}// ha a képek végére érünk akkor reseteljük az exploIndexet 
		public void update() {
				exploTick++;
				if(exploTick >= 12) {
					exploTick = 0;
					exploIndex++;
					
				}
			}
		
		public int getExploIndex() {
			return exploIndex;
		}
		public Point2D.Float getPos(){
			return pos;
		}
	}//A reset függvény azért kell hogy a játék újraindításakor ne legyenek még aktív projektilok
	public void reset() {
		projectileList.clear();
		explosionList.clear();
		projID = 0;
	}
	public ArrayList<Projectile> getProjectileList(){
		return projectileList;
	}
}
