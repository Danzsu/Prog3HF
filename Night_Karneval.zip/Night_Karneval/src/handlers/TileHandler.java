package handlers;

import static helpz.Constants.Tiles.*;
import helpz.ImgFix;
import helpz.LoadSave;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import objects.Tile;
//Összefoglalom a TileHandler osztályt
//A TileHandler osztály felelős a játékban használt tileok kezeléséért.
//A játékban használt tileok adatait tárolja, és a megfelelő tile-t adja vissza a megadott azonosító alapján.
//A TileHandler osztály a játékban használt tileok adatait tárolja, és a megfelelő tileok adja vissza a megadott azonosító alapján.
//A createTiles() metódusban inicializáljuk a tileokat, és hozzáadjuk őket a tiles listához.
//A loadBeta() metódusban betöltjük a spriteBeta képet.
//A getTile() metódus visszaadja a megadott azonosítójú tilet.
//A isSpriteAnimation() metódus visszaadja, hogy a megadott tile animációs-e.
//A getAniSprite() metódus visszaadja a megadott tile animációjának a megadott indexű képét.
//A getSprite() metódus visszaadja a megadott tile indexű képét.
public class TileHandler {	//Lehetett volna Map-ben vagy ArrayListben tárolni ....
	public Tile GRASS,WATER,ROAD,
	WATER_ROCK,BL_WATER,TL_WATER,TR_WATER,BR_WATER,
	MLD_WATER,MRD_WATER,MDU_WATER,MDD_WATER,
	ROAD_UP,TL_ROAD,TR_ROAD,BL_ROAD,BR_ROAD,
	WATER_PLANT,
	GRASS_PLANT_1,GRASS_PLANT_2,GRASS_BANNER;
	public BufferedImage beta;
	public ArrayList<Tile> tiles = new ArrayList<>();
	
	public ArrayList<Tile> roadsS = new ArrayList<>();
	public ArrayList<Tile> roadsC = new ArrayList<>();
	public ArrayList<Tile> wcorners = new ArrayList<>();
	public ArrayList<Tile> wmiddle = new ArrayList<>();
	public ArrayList<Tile> decors = new ArrayList<>();
	
	public TileHandler() {
		loadBeta();
		createTiles();
	}
	private void createTiles() {
		int id = 0;
		tiles.add(GRASS=new Tile(getSpriteBeta(8,2),id++,GRASS_TILE));
		tiles.add(WATER=new Tile(getAniSprites(0,0),id++,WATER_TILE));
	
		//egyszerű utak roadsS (roads simple)
		roadsS.add(ROAD=new Tile(getSpriteBeta(9,3),id++,ROAD_TILE));
		roadsS.add(ROAD_UP=new Tile(ImgFix.getRotImg(getSpriteBeta(9,3),90),id++,ROAD_TILE));
		
	
		//Utak sarokai roadsC(roads corners)
		roadsC.add(TL_ROAD=new Tile(getSpriteBeta(8,3),id++,ROAD_TILE));
		roadsC.add(TR_ROAD=new Tile(ImgFix.getRotImg(getSpriteBeta(8,3),90),id++,ROAD_TILE));
		roadsC.add(BL_ROAD=new Tile(ImgFix.getRotImg(getSpriteBeta(8,3),-90),id++,ROAD_TILE));
		roadsC.add(BR_ROAD=new Tile(ImgFix.getRotImg(getSpriteBeta(8,3),180),id++,ROAD_TILE));
		
		//animációs vizes sarok wcorners
	
		wcorners.add(TL_WATER=new Tile(ImgFix.getBuildRotImg(getAniSprites(0,0),getSprite(4,6),90),id++,WATER_TILE));
		wcorners.add(BL_WATER=new Tile(ImgFix.getBuildRotImg(getAniSprites(0,0),getSprite(4,6),0),id++,WATER_TILE));
		wcorners.add(TR_WATER=new Tile(ImgFix.getBuildRotImg(getAniSprites(0,0),getSprite(4,6),180),id++,WATER_TILE));
		wcorners.add(BR_WATER=new Tile(ImgFix.getBuildRotImg(getAniSprites(0,0),getSprite(4,6),270),id++,WATER_TILE));
		
		
		//Animációs Vizes blokkok közepe  wmiddle
		wmiddle.add(MLD_WATER=new Tile(ImgFix.getBuildRotImg(getAniSprites(0,0),getSprite(5,6),90),id++,WATER_TILE));
		wmiddle.add(MDU_WATER=new Tile(ImgFix.getBuildRotImg(getAniSprites(0,0),getSprite(5,6),180),id++,WATER_TILE));
		wmiddle.add(MRD_WATER=new Tile(ImgFix.getBuildRotImg(getAniSprites(0,0),getSprite(5,6),270),id++,WATER_TILE));
		wmiddle.add(MDD_WATER=new Tile(ImgFix.getBuildRotImg(getAniSprites(0,0),getSprite(5,6),0),id++,WATER_TILE));
		
		//dekoratív elemek
		decors.add(WATER_PLANT=new Tile(ImgFix.getBuildRotImg(getAniSprites(0,0),getSprite(2,8),0),id++,DECOR_TILE));
		decors.add(WATER_ROCK=new Tile(ImgFix.getBuildRotImg(getAniSprites(0,0),getSprite(3,8),0),id++,DECOR_TILE));
		decors.add(GRASS_PLANT_1=new Tile(ImgFix.buildImg(getImgs(8,2,0,8)),id++,DECOR_TILE));
		decors.add(GRASS_PLANT_2=new Tile(ImgFix.buildImg(getImgs(8,2,1,8)),id++,DECOR_TILE));
		decors.add(GRASS_BANNER=new Tile(ImgFix.buildImg(getImgs(8,2,4,8)),id++,DECOR_TILE));
		
		// hozzáadni a tiles hoz  az addAll al az egész lista tartalmát beletesszük
		tiles.addAll(roadsS);
		tiles.addAll(roadsC);
		tiles.addAll(wcorners);
		tiles.addAll(wmiddle);
		tiles.addAll(decors);
		
	}
	private BufferedImage[] getImgs(int firstX,int firstY,int secondX,int secondY) {
		return new BufferedImage[] {getSprite(firstX,firstY),getSprite(secondX,secondY)};
	}
	private BufferedImage[] getAniSprites(int xCord,int yCord) {
		BufferedImage[] array=new BufferedImage[4];
		for(int i = 0;i<4;i++) {
			array[i] = getSprite(xCord+i,yCord);
		}
		return array;
	}


	// Getters and Setters 
	private void loadBeta() {
		beta = LoadSave.getSpriteBeta();
	}
	public Tile getTile(int id) {
		//System.out.println(id); debugolláshoz jól jön
		return tiles.get(id);		
	}

	public boolean isSpriteAnimation(int spriteID) {
		return tiles.get(spriteID).isAnimation();
	}
	public BufferedImage getSprite(int id) {
		return tiles.get(id).getSprite();
	}
	public BufferedImage getAniSprite(int id,int animationIndex) {
		return tiles.get(id).getSprite(animationIndex);
	}
	
	private BufferedImage getSprite(int xCord,int yCord) {
		return beta.getSubimage(xCord*32, yCord*32, 32, 32);
	}
	
	public BufferedImage getSpriteBeta(int xCord,int yCord) {
		return beta.getSubimage(xCord*32, yCord*32, 32, 32);
	}
	public ArrayList<Tile> getRoadsS() {
		return roadsS;
	}
	public ArrayList<Tile> getRoadsC() {
		return roadsC;
	}
	public ArrayList<Tile> getWcorners() {
		return wcorners;
	}
	public ArrayList<Tile> getWmiddle() {
		return wmiddle;
	}
	public ArrayList<Tile> getDecors() {
		return decors;
	}

	 
}
