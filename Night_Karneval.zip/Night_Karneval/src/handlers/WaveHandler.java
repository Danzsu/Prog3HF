package handlers;

import java.util.ArrayList;
import java.util.Arrays;

import Events.Wave;
import scenes.Playing;
import static helpz.Constants.Enemies.*;
public class WaveHandler {
	
	private Playing playing;
	private ArrayList<Wave> waveList = new ArrayList<>();
	private int enemySpawnTickLimit = 60 *1; // 60 szor frissítünk mp-n ként így 60* x ahol x a mp száma ahány időközönként szeretnénk spawnolni
	private int enemySpawnTick;
	private int enemyIndex,waveIndex;
	private int waveTickLimit = 60*5; // 60 szor frissítünk mp-n ként
	private int waveTick = 0;
	private boolean waveStartTimer=false,waveTickTimerOver = false;
	
	
	public WaveHandler(Playing playing) {
		this.playing = playing;
		createWaves();
	}
	//először itt hozom létre de majd editingbe létrehozom később
	//itt frissítjük a waveket ha a spawnTick elérte a limitet akkor növeljük az enemyIndexet
	//ha a waveTick elérte a limitet akkor növeljük a waveIndexet tehát a következő wave következik
	public void update() {
		if(enemySpawnTick < enemySpawnTickLimit)
			enemySpawnTick++;
		if(waveStartTimer) {
			waveTick++;
			if(waveTick >= waveTickLimit) {
				waveTickTimerOver = true;
			}
		}
	}//itt indítjuk a következő wave-t
	public void incrWaveIndex() {
		waveIndex++;
		waveTick=0;
		waveTickTimerOver = false;
		waveStartTimer = false;

	}
	public boolean isWaveTimeOver() {
		return waveTickTimerOver;
	}
	public void startWaveTimer() {
		waveStartTimer = true;
		
	}
	public int getNextEnemy() {
		enemySpawnTick = 0;
		return waveList.get(waveIndex).getEnemyList().get(enemyIndex++);
		//vizsgálni kell hogy a lista végére értünk e
	}
	//itt hozzuk létre a waveket a különböző enemykkel
	//TODO itt akár majd a createWaves lehet paraméteres ahol a nehézséget kapja meg és az alapján switch case segítségével hozza létre a waveket
	private void createWaves() {
		// Itt adjuk hozzá a különböző waveket
		//SHAMAN WARRIOR MORDO SPRIGGAN MOSQUITO
		//waveList.add(new Wave(new ArrayList<Integer>(Arrays.asList(WARRIOR))));
		waveList.add(new Wave(new ArrayList<Integer>(Arrays.asList(WARRIOR,WARRIOR,WARRIOR,WARRIOR,WARRIOR))));
		waveList.add(new Wave(new ArrayList<Integer>(Arrays.asList(SHAMAN,WARRIOR,WARRIOR,WARRIOR,SHAMAN,SHAMAN))));
		waveList.add(new Wave(new ArrayList<Integer>(Arrays.asList(SHAMAN,MOSQUITO,MOSQUITO,MOSQUITO,MOSQUITO,MOSQUITO,MOSQUITO,MOSQUITO,MOSQUITO))));
		waveList.add(new Wave(new ArrayList<Integer>(Arrays.asList(SHAMAN,MOSQUITO,MOSQUITO,SPRIGGAN,WARRIOR,SPRIGGAN))));
		waveList.add(new Wave(new ArrayList<Integer>(Arrays.asList(WARRIOR,WARRIOR,WARRIOR,SPRIGGAN,SPRIGGAN,MOSQUITO,MOSQUITO,MOSQUITO))));
		waveList.add(new Wave(new ArrayList<Integer>(Arrays.asList(SPRIGGAN,MOSQUITO,MOSQUITO,MORDO))));
	}
	
	public ArrayList<Wave> getWaveList(){
		return waveList;
	}

	public boolean isTimeForNewEnemy() {
		
		return enemySpawnTick >= enemySpawnTickLimit; //ha eltelt a várni kívánt ídő true ha nem akkor false
	}
	
	public boolean isThereMoreEnemiesInCWave() {
		return (enemyIndex) < waveList.get(waveIndex).getEnemyList().size();
		//visszadja azt hogy az enemyIndex kisebb e mint az adott waveben lévő enemyList hossza tehát van e még enemy
		
	}


	public boolean isThereMoreWaves() {
		return waveIndex + 1 < waveList.size();
		// visszaadja azt hogy a waveIndex kisebb-e mint a wavek száma tehát van e még hátra wave
		// később növeljük a waveIndexet mint hogy ellenőriznénk a nextWave-t így kell egy +1
	}

	public void resetEnemyIndex() {
		enemyIndex =0;
		
	}
	
	public int getWaveIndex(){
		return waveIndex;
	}
	
	public float getTimeLeft() {
		float ticksLeft = waveTickLimit - waveTick;
		return ticksLeft / 60.0f;
		//így mp ben adjuk vissza
	}
	public boolean isWaveTimerStarted() {
		return waveStartTimer;
	}
	public void reset() {
		//Újraindításhoz vannak itt hogy minden előről induljon
		waveList.clear();
		createWaves();
		enemyIndex = 0;
		waveIndex = 0;
		waveStartTimer = false;
		waveTickTimerOver = false;
		waveTick = 0;
		enemySpawnTick = enemySpawnTickLimit;
	}
}
