package handlers;

import enemies.Enemy;
import helpz.LoadSave;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import objects.Tower;
import scenes.Playing;

//Összegezve a towerHandler osztály a tornyokkal foglalkozik
//A tornyokat tárolja, hozzáadja, eltávolítja, frissíti, kirajzolja, és a tornyokat kezeli
//A tornyokat a Playing osztályban hozzuk létre és a towerHandler osztályban táruljuk
//A tornyok képeit a towerImgs tömbben tároljuk és a loadTowerImgs metódusban töltjük be
//A tornyokat a towerList ArrayListben tároljuk azért mert így könnyebb lesz módosítani a towereket később mintha [] lenne
// a metódusok a towerHandler osztályban a következők:
// addTower(Tower selectedTower,int xPos,int yPos) - hozzáad egy tornyot a towerListhez 
// removeTower(Tower displayedTower) - eltávolít egy tornyot a towerListből 
// upgradeTower(Tower displayedTower) - fejleszti a tornyot 
// update() - frissíti a tornyokat és megtámadja az ellenségeket a hatósugarukban 
// attackEnemyWithinRange(Tower t) - megtámadja az ellenségeket a hatósugarukban 
// isEnemyInRange(Tower t, Enemy e) - megállapítja hogy az ellenség a torny hatósugarában van-e
// draw(Graphics g) - kirajzolja a tornyokat
// reset() - törli a towerListet és a towerAmountot visszaállítja 0-ra a játék újrakezdésekor

public class TowerHandler {
	
	private Playing playing;
	private BufferedImage[] towerImgs;
	private ArrayList<Tower> towerList = new ArrayList<>();// azért ArrayList mert így könnyebb lesz módosítani a towereket később mintha [] lenne
	private int towerAmount = 0;//ID a tornyoknak

	
	public TowerHandler(Playing playing) {
		this.playing=playing;
		
		loadTowerImgs();
	}
	private void loadTowerImgs() {
		BufferedImage beta = LoadSave.getSpriteBeta();
		towerImgs = new BufferedImage[3];
		for(int i =0;i<3;i++) {
			towerImgs[i]=beta.getSubimage(i*32, 9*32, 32, 32);
		}
	}
	public void addTower(Tower selectedTower,int xPos,int yPos) {
		towerList.add(new Tower(xPos,yPos,towerAmount++,selectedTower.getTowerType()));
		
	}
	
	public void removeTower(Tower displayedTower) {
		for(int i =0;i<towerList.size();i++) {
			if(towerList.get(i).getId()== displayedTower.getId())
				towerList.remove(i);
		}
	}
	public void upgradeTower(Tower displayedTower) {
		for(Tower t : towerList) {
			if(t.getId()==displayedTower.getId())
				t.upgradeTower();
		}
		
	}

	
	public void update() {
		for(Tower t: towerList) {
			t.update();
			attackEnemyWithinRange(t);
			
		}
	}
	// megtámadja az ellenségeket a hatósugarukban 
	private void attackEnemyWithinRange(Tower t) {
		
			for(Enemy e: playing.getEnemyHandler().getEnemies()) { 
				//System.out.println(" attackEnemy " + playing.getEnemyHandler().getEnemies().size());
				if(e.isAlive()) {
					if(isEnemyInRange(t,e)) // ha az ellenség a torny hatósugarában van
						// megtámadjuk az enemyt
						if(t.isCooldownOver()) {
							playing.shootEnemy(t,e);
							e.hurt(t.getDmg());
							t.resetCooldown();
						}
						else {
						//nem csinálunk semmit
					}
				}
				
			} 
				
	
		
	}// megállapítja hogy az ellenség a torny hatósugarában van-e		
	public boolean isEnemyInRange(Tower t, Enemy e) {
		int range = helpz.Utilz.GetRealDistance(t.getX(), t.getY(),  e.getX(),  e.getY());// a távolság a két objektum között 
		
		if(range<t.getRange())
			return true;
		else
			return false;
	}

	public void draw(Graphics g) {
	//	g.drawImage(towerImgs[ARCHER], tower.getX(), tower.getY(), null);
	for(Tower t : towerList) {
		g.drawImage(towerImgs[t.getTowerType()], t.getX(), t.getY(), null);
		}
	}
	public Tower getTowerAt(int x, int y) {
		for(Tower t : towerList) {
			if(t.getX()==x) 
				if(t.getY()==y)
					return t;
		
		}
		
		return null; // ha nincs rajta torony az adott pozíción
		
	}
	
	public BufferedImage[] getTowerImgs() {
		return towerImgs;
	}
	
	public void reset() {
		towerList.clear();
		towerAmount = 0;
	}
	public ArrayList<Tower> getTowerList(){
		return towerList;
	}
	
}
