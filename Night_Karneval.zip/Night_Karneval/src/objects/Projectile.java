package objects;

import java.awt.geom.Point2D;
// A lövedékeket reprezentáló osztály
// A lövedékek pozícióját, típusát, sebzését, sebességét és az aktívságát tárolja
// Az aktívságát azt jelenti, hogy a lövedék még aktív-e tehát még nem érte el a célpontját vagy nem ment ki a pályáról
// A lövedékek mozgatásáért felelős metódus is itt található a move()

public class Projectile {

	private Point2D.Float pos;// két floatot tárol és vannak hozzá metódusok pl distance(x,y)
	private int id,projectileType,dmg;
	private float xSpeed,ySpeed,rotation;
	private boolean active = true;

	public Projectile(float x, float y,float xSpeed, float ySpeed,int dmg,float rotation, int id , int projectileType) {
		pos = new Point2D.Float(x,y);
		this.xSpeed = xSpeed;
		this.ySpeed = ySpeed;
		this.dmg=dmg;
		this.rotation=rotation;
		this.projectileType = projectileType;
		this.id=id;
	}
	// A lövedékek újrahasznosításáért felelős metódus ez azért kell hogy ne kelljen folyamatosan új lövedékeket létrehozni a ProjectileHandlerben
	//Így nagyban csökkenthető a memória használat
	public void reuse(int x, int y, float xSpeed, float ySpeed, int dmg, float rotate) {
		pos = new Point2D.Float(x,y);
		this.xSpeed = xSpeed;
		this.ySpeed = ySpeed;
		this.dmg=dmg;
		this.rotation=rotate;
		active = true;

		
	}

	//Getterek és setterek

	public void move() {
		pos.x += xSpeed;
		pos.y += ySpeed;
	}
	public Point2D.Float getPos() {
		return pos;
	}
	public int getDmg() {
		return dmg;
	}
	public int getId() {
		return id;
	}
	public int getProjectileType() {
		return projectileType;
	}
	public boolean isActive() {
		return active;
	}
	public void setPos(Point2D.Float pos) {
		this.pos = pos;
	}
	
	
	public void setActive(boolean active) {
		this.active = active;
	}
	public float getRotation() {
		return rotation;
	}

	
}
