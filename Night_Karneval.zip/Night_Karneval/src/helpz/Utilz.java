package helpz;

import java.util.ArrayList;

public class Utilz {
	
	public static int[][] ListTo2d(ArrayList <Integer> list,int ySize,int xSize){
		int[][] newArr = new int[ySize][xSize];
		
		for(int j = 0 ; j< newArr.length;j++) {
			for(int i = 0; i< newArr[j].length;i++) {
				int index = j*ySize+i;
				newArr[j][i] = list.get(index);
			}
		}
		return newArr;
	}
	public static int[] Array2DTo1D(int[][] TwoArr) {
		int[] oneArr = new int [TwoArr.length * TwoArr[0].length];
		for(int j = 0 ; j< TwoArr.length;j++) {
			for(int i = 0; i< TwoArr[j].length;i++) {
				int index = j*TwoArr.length+i;
				oneArr[index] = TwoArr[j][i];
			}
		}
		return oneArr;
	}
	
	public static int GetRealDistance(float x1,float y1,float x2,float y2) {
		float xDiff = Math.abs(x1-x2);
		float yDiff = Math.abs(y1-y2);
		
		return (int) Math.hypot(xDiff, yDiff); // visszadjuk az átfogót ami a valós távolság köztük
	}
}
