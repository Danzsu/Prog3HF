package helpz;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import javax.imageio.ImageIO;
import objects.PathPoint;

public class LoadSave {

	public static BufferedImage getSpriteBeta() {
		BufferedImage img= null;
		InputStream is = LoadSave.class.getClassLoader().getResourceAsStream("spritebeta.png");
		try {
			img = ImageIO.read(is);
		} catch (IOException e) { // ha nem tudjuk beolvasni ezt akkor dobunk egy kivételt
			e.printStackTrace();
		}
		return img;
	}
	// itt új get metódusokkal fogom megvalósítani a másik fajta designt
	
	//txt file save hez
	public static void CreateFile() {
		
	
		File txtFile = new File("resources/testTextFile.txt");
		try {
			txtFile.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
	
	}
	// Create a new lvl with default values
		public static void CreateLevel(String name,int[] idArr) {
			File newLevel = new File("resources/"+ name +".txt"); 
			if(newLevel.exists()) {
				System.out.println("File: "+name+"already exists!");
				return;
			}else {
				try {
					newLevel.createNewFile();
				} catch (IOException e) {
					e.printStackTrace();
				}
				WriteToFile(newLevel,idArr,new PathPoint(0,0),new PathPoint(0,0));
			}
		}
	
	private static void WriteToFile(File file, int[] idArr,PathPoint start,PathPoint end) {
		
		try {
			PrintWriter pw = new PrintWriter(file);
			for(Integer i : idArr) {
				pw.println(i);
			}
			pw.println(start.getxCord());
			pw.println(start.getyCord());
			pw.println(end.getxCord());
			pw.println(end.getyCord());
			
			pw.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		
	}
	
	public static void SaveLevel(String name, int[][] idArr,PathPoint start,PathPoint end) {
		File lvlFile = new File("resources/"+ name +".txt"); 
		if(lvlFile.exists()) {
			WriteToFile(lvlFile,Utilz.Array2DTo1D(idArr),start,end);//itt 1 dimenzióssá teszem a 2d-s tömböt mert 20x20 as a pálya így 400 sort kell kapnunk
		}else {
			System.out.println("File: "+name+"nem létezik");
			return;
		}
	}
	
	private static ArrayList<Integer> ReadFromFile(File file) {
		ArrayList<Integer> list = new ArrayList<>();
		try {
			Scanner sc = new Scanner(file);
			
			while(sc.hasNext()) {
				list.add(sc.nextInt()); // ha nem működne akkor Integer.parseInt(sc.nextLine()) kellene
			}
			sc.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public static ArrayList<PathPoint> GetLevelPathPoints(String name){
		File lvlFile = new File("resources/"+name +".txt");
		if(lvlFile.exists()) {
			ArrayList<Integer> list = ReadFromFile(lvlFile);
			ArrayList<PathPoint> points = new ArrayList<>();
			points.add(new PathPoint(list.get(400),list.get(401)));
			points.add(new PathPoint(list.get(402),list.get(403)));
			
			return points;

		}else {
			System.out.println("File: "+name+"nem létezik");
			return null;
	}
}		
	
	public static int[][] GetLevelData(String name) {
		File lvlFile = new File("resources/"+name +".txt");
		if(lvlFile.exists()) {
			ArrayList<Integer> list = ReadFromFile(lvlFile);
			return Utilz.ListTo2d(list, 20, 20);
		}else {
			System.out.println("File: "+name+"nem létezik");
			return null;
		}
	}
	
	
}
