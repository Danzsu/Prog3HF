package helpz;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
//Ez az osztály azért fontos hogy a képeket megfelelően tudjuk forgatni és összeállítani a layerket tudjuk stackelni
public class ImgFix {
	// Rotate 
	//ez azért is fontos hogy az út tudjon elágazni
	// csak 90° és egyéb számszorosai szor fogunk forgatni
	//nem lenne értelme 33° al elforgatni egy tile-t hiszen a négyzeteket úgyis 90 és 180 fokkal forgatgatjuk elágazáshoz csak
	public static BufferedImage getRotImg(BufferedImage img,int rotAngle) {
		int w = img.getWidth();
		int h = img.getHeight();
		//img.getType() milyen típusú komponenseket teszünk bele rgb,bgr stb ami fontos hogy olyat tegyünk bele amit ki is akarunk majd rakni belőle
		BufferedImage newImg = new BufferedImage(w,h,img.getType());
		//Graphics2D extends Graphics ebben van benne a rotate és a scale metódusok amiket jó lenne használni
		Graphics2D g2d = newImg.createGraphics();
		
		//radiánba kéri a függvény a paramétereket így a Math ből a toRadians függvényt felkell használnunk az átalakításhoz hogy megfeleljen paraméterként
		g2d.rotate(Math.toRadians(rotAngle), w/2, h/2);//megkell adni azt hogy hova tegye a fix pontot amihez képpest forgat el, a mi esetünkben a középpontba lesz érdemes hiszen úgy érjük el a célunkat
		g2d.drawImage(img, 0, 0, null);
		g2d.dispose();//amennyire megértettem ez feloldja azt a forrást amit használt tehát olyan lehet mint egy megnyitott File esetén a file.close
	
		return newImg;
	}
	
	//Layers ez azért kell hogy a tornyokat és ellenségeket egymásra stackelni lehessen a pályára
	public static BufferedImage buildImg(BufferedImage[] imglist) {
		int w = imglist[0].getWidth();
		int h = imglist[0].getHeight();
		
		BufferedImage newImg = new BufferedImage(w,h,imglist[0].getType());
		Graphics2D g2d = newImg.createGraphics();
		
		//ezzel szintenként fogjuk felépíteni a képünket tehét a 0 indexű lesz legalul
		//olyan mint egy stack ha úgy tetszik a layerek stackelése kiadja a képet amit akaruk
		for(BufferedImage img:imglist) {
			g2d.drawImage(img, 0, 0, null);
		}
		
		g2d.dispose(); // "feloldjuk"
		return newImg;
	}
	//Roate second layer img a fenti kettőnek az ötvözése
	//Van egy layer amin animáció van de a felette lévő layert forgatnánk
	public static BufferedImage getBuildRotImg(BufferedImage[] imglist,int rotAngle,int rotAtIdx) {
		int w = imglist[0].getWidth();
		int h = imglist[0].getHeight();
		
		BufferedImage newImg = new BufferedImage(w,h,imglist[0].getType());
		Graphics2D g2d = newImg.createGraphics();
		for(int i =0;i<imglist.length;i++) {
			if(rotAtIdx==i) {
				g2d.rotate(Math.toRadians(rotAngle),w/2,h/2); // elforatjuk a megadott szöggel a megadott layer szint indexel rendelkező kép layert a képen
				g2d.drawImage(imglist[i], 0, 0,null);
				g2d.rotate(Math.toRadians(-rotAngle),w/2,h/2);
			}
			else {
				g2d.drawImage(imglist[i], 0, 0,null);
			}
		}
		g2d.dispose();
		return newImg;
	}
	
	//Van egy layer amin animáció van de a felette lévő layert forgatnánk
	//Ez azért kell hogy több tile-t is forgathassunk egyszerre  úgy hogy az animációk is forgatva legyenek
		public static BufferedImage[] getBuildRotImg(BufferedImage[] animationlist,BufferedImage secondImage,int rotAngle) {
			int w = animationlist[0].getWidth();
			int h = animationlist[0].getHeight();
			
			
			BufferedImage[] array = new BufferedImage[animationlist.length]; // az animáció hossza
			for(int i =0;i<animationlist.length;i++) {
				BufferedImage newImg = new BufferedImage(w,h,animationlist[0].getType());
				Graphics2D g2d = newImg.createGraphics();
				
				g2d.drawImage(animationlist[i], 0, 0,null);
				g2d.rotate(Math.toRadians(rotAngle),w/2,h/2);
				g2d.drawImage(secondImage, 0, 0,null);
				g2d.rotate(Math.toRadians(-rotAngle),w/2,h/2);
				g2d.dispose();
				
				array[i] = newImg;
			}
		
			return array;
		}

}
