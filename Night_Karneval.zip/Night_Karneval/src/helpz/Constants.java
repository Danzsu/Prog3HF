package helpz;

public class Constants {
//olyan elemeket tárolunk ebben a classban amiknek az értékét nem változtatjuk
// checkoláshoz if feltételekhez fogjuk használni őket
// pl: if(towerType == Constants.Towers.CANNON) { ... }
	public static class Projectiles{
		public static final int ARROW =0;  // Gunslinger
		public static final int BOMB = 1;
		public static final int MAGIC = 2;
		
		public static float GetSpeed(int projectileType) {
			switch(projectileType) {
			case ARROW:
				return 6f;
			case BOMB:
				return 2f;
			case MAGIC:
				return 4f;
			}
			return 0f;
		}
	}
	public static class Direction{
		public static final int LEFT =0;
		public static final int UP =1;
		public static final int RIGHT =2;
		public static final int DOWN =3;
	}

	public static class Tiles{
		public static final int WATER_TILE = 0;
		public static final int GRASS_TILE = 1;
		public static final int ROAD_TILE = 2;
		public static final int DECOR_TILE =3;

	}
	public static class Enemies{
		public static final int WARRIOR =0;
		public static final int SHAMAN = 1;
		public static final int MOSQUITO = 2;
		public static final int MORDO = 3;
		public static final int SPRIGGAN = 4;
		
		public static int GetDmgToPlayer(int enemyType) {
			switch(enemyType) {
			case WARRIOR:
				return 1;
			case SHAMAN:
				return 2;
			case MOSQUITO:
				return 1;
			case MORDO:
				return 10;
			case SPRIGGAN:
				return 3;
			}
			return 0;
		}
		
		public static int GetReward(int enemyType) {
			switch(enemyType) {
			case WARRIOR:
				return 15;
			case SHAMAN:
				return 10;
			case MOSQUITO:
				return 5;
			case MORDO:
				return 500;
			case SPRIGGAN:
				return 25;
			}
			return 0;
		}
		
		public static float GetSpeed(int enemyType) {
			switch(enemyType) {
			case WARRIOR:
				return 0.35f;
			case SHAMAN:
				return 0.4f;
			case MOSQUITO:
				return 0.75f;
			case MORDO:
				return 0.5f;
			case SPRIGGAN:
				return 0.65f;
			}
			return 0;
		}
		
		public static final int GetStartHealth(int enemyType) {
			switch(enemyType) {
			case WARRIOR:
				return 250;
			case SHAMAN:
				return 100;
			case MOSQUITO:
				return 40;
			case MORDO:
				return 2000;
			case SPRIGGAN:
				return 350;
			}
			return 0;
		}
	}
	
	public static class Towers{
		public static final int CANNON = 0;  // Gunslinger
		public static final int WIZARD = 1;
		public static final int ARCHER = 2;
		
		public static int GetTowerPrice(int towerType) {
			switch(towerType) {
			case CANNON:
				return 65;
			case WIZARD:
				return 45;
			case ARCHER:
				return 30;
			}
			return 0;
		}
		
		public static String GetName(int towerType) {
			switch(towerType) {
			case CANNON:
				return "Cannon";
			case WIZARD:
				return "Wizard";
			case ARCHER:
				return "Archer";
			}
			return "";
		}
	
		//azért floatok hogy ha manipulálni akarjuk őket akkor lehessen tört is
		//
		
		public static int GetStartDmg(int towerType) {
			switch(towerType) {
			case CANNON:
				return 20;
			case WIZARD:
				return 0;
			case ARCHER:
				return 5;
			}
			return 0;
		}
		public static float GetDefaultRange(int towerType) {
			switch(towerType) {
			case CANNON:
				return 100;
			case WIZARD:
				return 125;
			case ARCHER:
				return 155;
			}
			return 0;
		}
		public static float GetDefaultCooldown(int towerType) {
			switch(towerType) {
			case CANNON:
				return 80;
			case WIZARD:
				return 40;
			case ARCHER:
				return 25;
			}
			return 0;
		}
	}
}
