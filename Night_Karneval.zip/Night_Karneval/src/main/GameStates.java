package main;
// Egy enum osztály, amely a játék állapotait tartalmazza.
public enum GameStates {
	
	PLAYING,MENU,SETTINGS,EDIT,GAME_OVER,VICTORY;
	
	public static GameStates gameState = MENU;
	
	public static void setGameState(GameStates state) {
		gameState = state;
	}

}
