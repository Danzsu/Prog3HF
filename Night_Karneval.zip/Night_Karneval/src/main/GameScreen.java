package main;
import inputs.KeyboardListener;
import inputs.MyMouseListener;
import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JPanel;

public class GameScreen extends JPanel {
	//Változók 
	private static final long serialVersionUID = 1L;
	protected Game game;

	private Dimension size;
	
	private MyMouseListener myMouseListener;
	private KeyboardListener keyboardListener;
	
	//Konstruktor
	public GameScreen(Game game) {
		this.game= game;
		
		setPanelSize();
		
	
	}
	
	public void initInputs() {
		myMouseListener= new MyMouseListener(game);
		keyboardListener = new KeyboardListener(game);
		
		addMouseListener(myMouseListener);
		addMouseMotionListener(myMouseListener);
		addKeyListener(keyboardListener);
		
		requestFocus();// requestFocusInWindow() ez lehet jobb lesz ide 
		//A requestFocus() gondoskodik róla, hogy a komponens azonnal képes legyen fogadni a billentyűleütéseket. 
	}
	
	private void setPanelSize() {// a panel méretét állítja be 
		size = new Dimension(640,800); //eddig setSize(1024,1024)-ot használtam de voltak elemek amik lelógtak 
		setMinimumSize(size);
		setMaximumSize(size);
		setPreferredSize(size);
	}

	
	//Ez a metódus felelős a játék kirajzolásáért 
	public void paintComponent(Graphics G) {	// a Graphicsban vannak olyan függvények amiket megjelenítéshez használunk lásd fillRect drawRect
		super.paintComponent(G);
		//G.drawImage(sprites.get(19), 0, 0, null); így rajzolunk ki egy elemet a spritesból
		game.getRender().render(G);// a render metódus a Render osztályban felelős a kirajzolásért 
		}
	
}
