package main;

import java.awt.Graphics;

public class Render {
		private Game game;
		
		
		
		public Render(Game game) {
			this.game=game;
			
		}
	
		//a render metódus felel a játék megjelenítéséért a játék állapotától függően különböző dolgokat rajzol ki a képernyőre
		//Pl: ha a játék állapota MENU akkor a menüt rajzolja ki ha a játék állapota PLAYING akkor a játékot rajzolja ki
		public void render(Graphics g) {
			
			switch(GameStates.gameState) {
			
			case MENU:
				game.getMenu().render(g);
				break;
			case PLAYING:
				game.getPlaying().render(g);
				break;
			case SETTINGS: //settings ide mennének a nehézségek ami szerint a PLAYING ben létrehozza a waveket
				game.getSettings().render(g);
				break;
			case EDIT:
				game.getEditor().render(g);
				break;
			case GAME_OVER:
				game.getGameOver().render(g);
				break;
			case VICTORY:
				game.getVictory().render(g);
				break;
			default:
				break;
			
			}
		}
	
}
