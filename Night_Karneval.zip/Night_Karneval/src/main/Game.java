package main;

import handlers.TileHandler;
import helpz.LoadSave;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import scenes.Editing;
import scenes.GameOver;
import scenes.Menu;
import scenes.Playing;
import scenes.Settings;
import scenes.Victory;

public class Game extends JFrame implements Runnable {
	private static final long serialVersionUID = 1L;

	private final double FPS_CAP = 180.0;
	private final double UPS_CAP = 90.0;

	private GameScreen gameScreen;
	private Thread gameThread;

	
	
	// külső osztályok
	private  Render render;
	private Menu menu;
	private Playing playing;
	private Settings settings;
	private Editing edit;
	private GameOver gameOver;
	private Victory victory;
	private ImageIcon icon;
	private TileHandler tileHandler;

	public Game() { // a konstruktor végétől a játék futása a run() metódusban történik
		

		setDefaultCloseOperation(EXIT_ON_CLOSE);// ha az x re kattintunk megáll a program, defaultként nem csinál semmit  ha rákattintunk										
		initClasses();
		createDefaultLevel();
		add(gameScreen);
		
		pack(); // a megfelelő méretre szabja az ablakot szintén a legvégére kell, ehhez kellett a dimension típus
		setTitle("Fairy Karneval");
		setIconImage(icon.getImage());
		setResizable(false);// így mindig fix méretű lesz az ablak
		setLocationRelativeTo(null);// ez az ablakot alapértelmezettként középre orientálja
		setVisible(true); // mindig a végére tesszük így biztosan mindent megjelenít
		
	}
	// a createDefaultLevel() metódus a játék indulásakor létrehoz egy alapértelmezett pályát ha még nincs ilyen a játékban
	private void createDefaultLevel() {
		int[]arr = new int[400];
		for(int i = 0;i<arr.length;i++) {
			arr[i]= 0;
		}
		LoadSave.CreateLevel("new level", arr); //betölti a pályát aha még nincs ilyen a játékban
	}
	private void initClasses() {
		icon = new ImageIcon(getClass().getResource("/icon.png"));
		tileHandler = new TileHandler();
		gameScreen = new GameScreen(this);
		render = new Render(this);
		menu = new Menu(this);
		playing = new Playing(this);
		settings = new Settings(this);
		edit = new Editing(this);
		gameOver = new GameOver(this);
		victory = new Victory(this);
		
	}
	
	


	private void start() {
		gameThread = new Thread(this) {
		}; // miért is elég itt a this-t berakni azért mert az osztály megvalósítja a
			// runnable run() metódusát így nincs szükség közvetlenül bele írni
		gameThread.start();
	}

	// ez a metódus a játék frissítéséért felelős
	// az update a játék logikáját tartalmazza a render a megjelenítést frissíti
	private void updateGame() {
		switch(GameStates.gameState) {
		case EDIT:
			edit.update();
			break;
		case MENU:
			break;
		case PLAYING:
			playing.update();
			break;
		case SETTINGS:
			break;
		default:
			break;
		
		}
		// System.out.println("Game Updated!");

	}

	// MAIN 
	// a main metódusban hozzuk létre a játékot és indítjuk el
	public static void main(String[] args) {
		System.out.println("Játék indítása...");
		Game game = new Game();
		game.gameScreen.initInputs();
		
		game.start();// a játék indítása

	}

	@Override
	public void run() {
		// a Game loop kerül ide
		// a game loop azért kell mert a játékot folyamatosan frissíteni kell
		// a System.currentTimeMillis az embereknek szánt időzítéshez jobb
		// míg a nanotime azért jobb mert pontosabb így a játék működését stabilabbá
		// teszi
		double timePerUpdate = 1000000000.0 / UPS_CAP;// 1 mp = 1 milliárd nanoszekundum a logika frissítéséhez nem kell  annyira gyorsan frissíteni mint a megjelenítéshez
														
		double timePerFrame = 1000000000.0 / FPS_CAP;// 1 mp = 1 milliárd nanoszekundum  ez azért kell hogy a  képfrissítés se legyen túl gyors

														
		long lastFrame = System.nanoTime();
		long lastUpdate = System.nanoTime();
		long lastTimeCheck = System.currentTimeMillis();
		long now;

		int frames = 0;
		int updates = 0;
		// a játék futása a while ciklusban történik amíg a játék fut addig a ciklus is fut
		while (true) {
			now = System.nanoTime();// a játék futásának idejét méri nanoszekundumban
			// Render a játék megjelenítésének frissítése
			if (now - lastFrame >= timePerFrame) {
				lastFrame = now; // itt állítjuk be hogy most frissítettünk
				repaint(); // meghívja a paintComponent-et újra ez az ami frissíti a grafikus részt ( a
							// megjelenített elemeket)
				frames++; // System.nanoTime() egy Java metódus egy nagy pontosságú, időmérési művelethez
							// használt metódus, amely a rendszer órájának aktuális értékét nanomásodpercben
							// adja vissza.
							// azért kell hogy fenntartsuk a megfelelő fps számot
			}

			// Update a játék logikájának frissítése
			if (now - lastUpdate >= timePerUpdate) {
				updateGame();// a játék logikájának frissítése
				lastUpdate = now;
				updates++;
			}
			// FPS és UPS ellenőrzés minden másodpercben

			if (System.currentTimeMillis() - lastTimeCheck >= 1000) {// minden másodpercben kiírja a képfrissítés arányt
				System.out.println("FPS: " + frames + " | UPS: " + updates);
				frames = 0;
				updates = 0;
				lastTimeCheck = System.currentTimeMillis(); // itt beállítjuk hogy utoljára most frissítettünk
			}

		}
	}

	// Getter and setter rész
	public  Render getRender() {
		return render;
	}
	public Menu getMenu() {
		return menu;
	}
	
	public Playing getPlaying() {
		return playing;
	}
	
	public Settings getSettings() {
		return settings;
	}
	public Editing getEditor() {
		return edit;
	}
	
	public TileHandler getTileHandler(){
		return tileHandler;
	}
	public GameOver getGameOver() {
		return gameOver;
	}
	public Victory getVictory() {
		return victory;
	}
	//TODO a játék megalkotásához szerzett tudások az előadáson kívül:
	//Kaarin Gaming youtube tutorialjából 
	//RyiSnow youtube 2D Game java tutorialjából 
	//Ra Ven youtube Graphics 2D tutorialjából
}
